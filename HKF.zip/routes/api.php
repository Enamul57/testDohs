<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DataController;
use App\Http\Controllers\ManagerUserController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\ProjectStageController;

use App\Http\Controllers\ClientInfoController;
use App\Http\Controllers\ClientStatusController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\PurchaseReturnAllController;
use App\Http\Controllers\AccountHeadController;
use App\Http\Controllers\ReceiptAccountController;
use App\Http\Controllers\ReceiptVoucherController;
use App\Http\Controllers\PaymentAccountController;
use App\Http\Controllers\PaymentVoucherController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\PurchasedJournalController;
use App\Http\Controllers\AccountPayableJournalController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\PurchaseLedgerController;
use App\Http\Controllers\ApLedgerController;
use App\Http\Controllers\BankLedgerController;
use App\Http\Controllers\CashLedgerController;
use App\Http\Controllers\SalesLedgerController;
use App\Http\Controllers\ReceiptPayableLedgerController;
use App\Http\Controllers\PayPayableController;
use App\Http\Controllers\PayReceivableController;
use App\Http\Controllers\GetApNameController;
use App\Http\Controllers\PurchaseReturnController;
use App\Http\Controllers\PurchaseLandController;
use App\Http\Controllers\getSupplierForCashLedger;
use App\Http\Controllers\getSupplierForBankLedger;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\SalaryController;
use App\Http\Controllers\TrialBalanceController;
use App\Http\Controllers\getPurchaseLedgerSupplierController;
use App\Http\Controllers\getSalesLedgerSupplierController;
use App\Http\Controllers\ConsumeStockController;
use App\Http\Controllers\StockJournalController;
use App\Http\Controllers\ReferenceController;
use App\Http\Controllers\ReferenceInfoController;
use App\Http\Controllers\notificationController;
use App\Http\Controllers\AccountsAccessController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post('admin/register',[App\Http\Controllers\UserController::class,'register']);
Route::post('admin/login', [App\Http\Controllers\UserController::class,'authenticate']);
Route::get('admin/open', [App\Http\Controllers\DataController::class,'open']);

Route::group(['middleware' => ['jwt.verify']], function() {
    Route::get('admin/user', [App\Http\Controllers\UserController::class,'getAuthenticatedUser']);
    Route::get('admin/closed', [App\Http\Controllers\DataController::class,'closed']);
});
Route::post('manager/register',[App\Http\Controllers\ManagerUserController::class,'register']);
Route::post('manager/login', [App\Http\Controllers\ManagerUserController::class,'authenticate']);
Route::get('manager/open', [App\Http\Controllers\DataController::class,'open']);

Route::group(['middleware' => ['jwt.verify']], function() {
    Route::get('manager/user', [App\Http\Controllers\ManagerUserController::class,'getAuthenticatedUser']);
    Route::get('manager/closed', [App\Http\Controllers\ManagerDataController::class,'closed']);
});




//dashboard
Route::apiResource('/project',App\Http\Controllers\ProjectController::class);
Route::post('/updateProject',[App\Http\Controllers\ProjectController::class,'updateProject']);

Route::apiResource('/project_stage',App\Http\Controllers\ProjectStageController::class);
Route::get('/getStage/{id}',[App\Http\Controllers\GetApNameController::class,'getStage']);


Route::apiResource('/client',App\Http\Controllers\ClientInfoController::class);
Route::apiResource('/client_status',App\Http\Controllers\ClientStatusController::class);
Route::post('/client/existing_entry/',[ClientInfoController::class,'storeExist']);
Route::get('/client_info/{client_id}',[App\Http\Controllers\ClientInfoController::class,'getClientInfo']);



Route::apiResource('/purchase_return_all',App\Http\Controllers\PurchaseReturnAllController::class);
Route::apiResource('/account_head',App\Http\Controllers\AccountHeadController::class);
Route::get('/fetch_client_project/{client_nid}',[App\Http\Controllers\ClientInfoController::class,'getProjectFromClientInfo']);

Route::apiResource('/receipt_voucher',App\Http\Controllers\ReceiptVoucherController::class);
Route::post('/receipt_voucher_update',[App\Http\Controllers\ReceiptVoucherController::class,'receiptUpdate']);


Route::apiResource('/payment_voucher',App\Http\Controllers\PaymentVoucherController::class);
Route::post('/payment_voucher_update',[App\Http\Controllers\PaymentVoucherController::class,'paymentUpdate']);
Route::apiResource('/unit',App\Http\Controllers\UnitController::class);
Route::get('/filterUnit/{itemName}',[App\Http\Controllers\UnitController::class,'filterUnit']);




// App\Http\Controllers\AccountPayableJournalController

Route::apiResource('/purchased_journal',App\Http\Controllers\PurchasedJournalController::class);
Route::get('/purchased_journal/daily_journal/{date}',[App\Http\Controllers\PurchasedJournalController::class,'perDatePurchasedVoucher']);
Route::get('/purchased_journal/getbypamentid/{payment_id}',[App\Http\Controllers\PurchasedJournalController::class,'getByPaymentId']);
Route::get('/purchased_journal/getID/{payment_id}',[App\Http\Controllers\PurchasedJournalController::class,'getID']);
Route::apiResource('/accounts_payable',App\Http\Controllers\AccountPayableJournalController::class);
Route::get('/accounts_payable/daily_journal/{throw_date}',[App\Http\Controllers\AccountPayableJournalController::class,'fetchAccountsPayableByDate']);
Route::get('/purchased_journal/getjournal/{id}',[App\Http\Controllers\PurchasedJournalController::class,'getJournal']);
Route::get('/purchased_journal/getjournalEdit/{id}',[App\Http\Controllers\PurchasedJournalController::class,'getjournalEdit']);

//inventory
Route::apiResource('/inventory',App\Http\Controllers\InventoryController::class);
Route::post('/checkPropertyId',[App\Http\Controllers\GetApNameController::class,'checkPropertyId']);

//journal ledger
Route::apiResource('/receipt_journal',App\Http\Controllers\ReceiptJournalController::class);
Route::get('/receipt_journal/daily_journal/{date}',[App\Http\Controllers\ReceiptJournalController::class,'perDateReceiptVoucher']);
Route::get('/receipt_journal/getbyreceiptid/{receipt_id}',[App\Http\Controllers\ReceiptJournalController::class,'getByReceiptId']);
Route::get('/receipt_journal/getID/{receipt_id}',[App\Http\Controllers\ReceiptJournalController::class,'getID']);

Route::apiResource('/accounts_receivable',App\Http\Controllers\ReceiptPayableJournalController::class);

Route::get('/accounts_receivable/daily_journal/{throw_date}',[App\Http\Controllers\ReceiptPayableJournalController::class,'fetchAccountsReceivableByDate']);
Route::apiResource('/supplier',App\Http\Controllers\SupplierController::class);
Route::apiResource('/purchase_ledger',App\Http\Controllers\PurchaseLedgerController::class);
Route::post('/purchase_ledger/pass_ldg',[App\Http\Controllers\PurchaseLedgerController::class,'receiveLdg']);
Route::apiResource('/ap_ledger',App\Http\Controllers\ApLedgerController::class);
Route::post('/ap_ledger/pass_ldg',[App\Http\Controllers\ApLedgerController::class,'receiveLdg']);
Route::apiResource('/bank_ledger',App\Http\Controllers\BankLedgerController::class);
Route::post('/bank_ledger/pass_ldg',[App\Http\Controllers\BankLedgerController::class,'receiveLdg']);
Route::apiResource('/sales_ledger',App\Http\Controllers\SalesLedgerController::class);
Route::post('/sales_ledger/pass_ldg',[App\Http\Controllers\SalesLedgerController::class,'receiveLdg']);
Route::apiResource('/rp_ledger',App\Http\Controllers\ReceiptPayableLedgerController::class);
Route::post('/rp_ledger/pass_ldg',[App\Http\Controllers\ReceiptPayableLedgerController::class,'receiveLdg']);

Route::apiResource('/cash_ledger',App\Http\Controllers\CashLedgerController::class);
Route::post('/cash_ledger/pass_ldg',[App\Http\Controllers\CashLedgerController::class,'receiveLdg']);

Route::apiResource('/pay_payable',App\Http\Controllers\PayPayableController::class);
Route::apiResource('/receipt_payable',App\Http\Controllers\PayReceivableController::class);

Route::post('/getPayableName/getJournal',[App\Http\Controllers\GetApNameController::class,'getApName']);
Route::get('/getApledger',[App\Http\Controllers\GetApNameController::class,'getApLedger']);
Route::get('/getPayableData/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getPayableData']);
Route::get('/getPaymentVoucher/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getPaymentVoucher']);
Route::get('/getPayableName/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getName']);
Route::get('/getReceiptPayableName/{receipt_id}',[App\Http\Controllers\GetApNameController::class,'getReceiptName']);

Route::get('/getPurchaseReturns/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getPurchaseReturns']);
Route::post('/filterProductType',[App\Http\Controllers\GetApNameController::class,'filterProductType']);
Route::post('/getBuildingName',[App\Http\Controllers\GetApNameController::class,'getBuildingName']);
Route::post('/getPropertyLabel',[App\Http\Controllers\GetApNameController::class,'getPropertyLabel']);
Route::post('/getPropertyId',[App\Http\Controllers\GetApNameController::class,'getPropertyId']);
Route::post('/getProductTotal',[App\Http\Controllers\GetApNameController::class,'getProductTotal']);
Route::get('/getPayableID/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getPayableID']);
Route::get('/checkDueClear/{payment_id}',[App\Http\Controllers\GetApNameController::class,'checkDueClear']);
Route::get('/checkDueClearReceipt/{receipt_id}',[App\Http\Controllers\GetApNameController::class,'checkDueClearReceipt']);

Route::get('/checkReturns/{payment_id}',[App\Http\Controllers\GetApNameController::class,'checkReturns']);
Route::get('/getFirstInstall/{payment_id}',[App\Http\Controllers\GetApNameController::class,'getFirstInstall']);
Route::get('/getFirstInstallReceipt/{receipt_id}',[App\Http\Controllers\GetApNameController::class,'getFirstInstallReceipt']);

Route::get('/getApledgerRcpt',[App\Http\Controllers\GetApNameController::class,'getApledgerRcpt']);
Route::get('/getUnit/{product_name}',[App\Http\Controllers\GetApNameController::class,'getUnit']);
Route::get('/getReference/{voucher}',[App\Http\Controllers\GetApNameController::class,'getReference']);
Route::post('/reference_clients',[App\Http\Controllers\GetApNameController::class,'reference_clients']);

Route::apiResource('/purchase_return',App\Http\Controllers\PurchaseReturnController::class);

Route::apiResource('/purchase_land_details',App\Http\Controllers\PurchaseLandController::class);

//fetch supplier for bank cash ledgers
Route::apiResource('/cash_suppliers',App\Http\Controllers\getSupplierForCashLedger::class);
Route::apiResource('/bank_suppliers',App\Http\Controllers\getSupplierForBankLedger::class);
Route::apiResource('/sales_suppliers',App\Http\Controllers\getSalesLedgerSupplierController::class);
Route::apiResource('/purchase_suppliers',App\Http\Controllers\getPurchaseLedgerSupplierController::class);
//expense

Route::apiResource('/expense',App\Http\Controllers\ExpenseController::class);
Route::post('/expense/totalExpense',[App\Http\Controllers\ExpenseController::class,'totalExpense']);

//employee
Route::apiResource('/employee',App\Http\Controllers\EmployeeController::class);
Route::post('/employee/updateEmployee',[App\Http\Controllers\EmployeeController::class,'updateEmployee']);

//salary
Route::apiResource('/salary',App\Http\Controllers\SalaryController::class);
Route::get('/salary/getSalaryHistory/{employee_id}',[App\Http\Controllers\SalaryController::class,'getSalaryHistory']);
Route::post('/salary/totalSalary',[App\Http\Controllers\SalaryController::class,'totalSalary']);

//tiral balance

Route::post('/trial_balance',[App\Http\Controllers\TrialBalanceController::class,'trialBalance']);

//calculate amount for dashboard
Route::get('/getPurchaseAmount',[App\Http\Controllers\GetApNameController::class,'getPurchaseAmount']);
Route::get('/getSalesAmount',[App\Http\Controllers\GetApNameController::class,'getSalesAmount']);
Route::get('/getPaymentDue',[App\Http\Controllers\GetApNameController::class,'getPaymentDue']);
Route::get('/getReceiptDue',[App\Http\Controllers\GetApNameController::class,'getReceiptDue']);

//pie chart
Route::get('/piechart',[App\Http\Controllers\GetApNameController::class,'pieChart']);
Route::get('/areachart',[App\Http\Controllers\GetApNameController::class,'areaChart']);

//Requisition and stock journal
Route::apiResource('/stock_journal',App\Http\Controllers\StockJournalController::class);
Route::apiResource('/requisition',App\Http\Controllers\ConsumeStockController::class);
Route::get('/fetchStock/{product_name}',[App\Http\Controllers\GetApNameController::class,'fetchStock']);

//member
Route::apiResource('/project_member',App\Http\Controllers\ProjectMemberController::class);
//reference
Route::apiResource('/reference',App\Http\Controllers\ReferenceController::class);
//reference info
Route::apiResource('/reference_info',App\Http\Controllers\ReferenceInfoController::class);
Route::get('/project_lists',[App\Http\Controllers\GetApNameController::class,'project_lists']);
Route::get('/fetchProjectFromLists/{id}',[App\Http\Controllers\GetApNameController::class,'fetchProjectFromLists']);
Route::get('/fetchMemberByProject/{project}',[App\Http\Controllers\GetApNameController::class,'fetchMemberByProject']);

//manager approve
Route::get('/managerUsername/{username}',[App\Http\Controllers\GetApNameController::class,'managerUsername']);
Route::get('/getAllManager',[App\Http\Controllers\GetApNameController::class,'getAllManager']);
Route::apiResource('/manager_approve',App\Http\Controllers\ManagerApproveController::class);
Route::get('/getManagerProject/{username}',[App\Http\Controllers\GetApNameController::class,'getManagerProject']);
Route::get('/getManagerProjectClient/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerProjectClient']);
Route::get('/getClientAllProject/{client}',[App\Http\Controllers\GetApNameController::class,'getClientAllProject']);
Route::get('/getManagerProjectInventory',[App\Http\Controllers\GetApNameController::class,'getManagerProjectInventory']);
Route::get('/getManagerAll',[App\Http\Controllers\GetApNameController::class,'getManagerAll']);
Route::delete('/manager_delete/{id}',[App\Http\Controllers\GetApNameController::class,'manager_delete']);
Route::get('/check_admin_current_password/{password}',[App\Http\Controllers\GetApNameController::class,'check_admin_current_password']);
Route::get('/check_manager_current_password/{password}',[App\Http\Controllers\GetApNameController::class,'check_manager_current_password']);
Route::post('/update_admin_current_password',[App\Http\Controllers\GetApNameController::class,'update_admin_current_password']);
Route::post('/update_manager_current_password',[App\Http\Controllers\GetApNameController::class,'update_manager_current_password']);
Route::get('/getClientProject/{project}',[App\Http\Controllers\GetApNameController::class,'getClientProject']);

Route::get('/getReceiptvouchers/{project}',[App\Http\Controllers\GetApNameController::class,'getReceiptvouchers']);
Route::get('/getPaymentvouchers/{project}',[App\Http\Controllers\GetApNameController::class,'getPaymentvouchers']);

Route::get('/getManagerPayable/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerPayable']);

Route::get('/getManagerPayableAll/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerPayableAll']);

Route::get('/getManagerReceiptPayable/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerReceiptPayable']);
Route::get('/getManagerReceivableAll/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerReceivableAll']);

//notification
Route::apiResource('/notification',App\Http\Controllers\notificationController::class);

Route::get('/reset_notification',[App\Http\Controllers\GetApNameController::class,'reset_notification']);

//accounts access

Route::apiResource('/accounts_access',App\Http\Controllers\AccountsAccessController::class);
Route::get('/fetch_access/{manager}',[App\Http\Controllers\GetApNameController::class,'fetch_access']);


Route::get('/manager_fetch_employee/{project}',[App\Http\Controllers\GetApNameController::class,'manager_fetch_employee']);

Route::get('/manager_fetch_expense/{project}',[App\Http\Controllers\GetApNameController::class,'manager_fetch_expense']);

//fetch client id base on voucher
Route::get('/fetch_client',[App\Http\Controllers\GetApNameController::class,'fetch_client']);
Route::get('/fetch_client_by_project/{project}',[App\Http\Controllers\GetApNameController::class,'fetch_client_by_project']);

Route::get('/fetch_client_accounts/{client_id}',[App\Http\Controllers\GetApNameController::class,'fetch_client_accounts']);

Route::get('/getManagerProjectClientList/{project}',[App\Http\Controllers\GetApNameController::class,'getManagerProjectClientList']);
Route::get('/fetch_project/{project}',[App\Http\Controllers\GetApNameController::class,'project']);

Route::get('/fetch_access_manager',[App\Http\Controllers\GetApNameController::class,'fetch_access_manager']);

Route::delete('/delete_accounts_access/{id}',[App\Http\Controllers\GetApNameController::class,'delete_accounts_access']);
