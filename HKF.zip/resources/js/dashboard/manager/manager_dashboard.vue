<template>
  <div>
    <!-- Begin Page Content -->
    <div class="container-fluid">
      <!-- Page Heading -->
      <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h2 class="hkf_text text-center mb-4" style="font-weight: 400">Dashboard</h2>
      </div>

      <!-- Content Row -->
      <div class="row">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="font-weight-bold text-primary text-uppercase mb-1">
                    Purchase Amount
                  </div>
                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                    {{ purchaseAmount }} tk
                  </div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-calendar fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="font-weight-bold text-success text-uppercase mb-1">
                    Sales Amount
                  </div>
                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                    {{ salesAmount }} tk
                  </div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="font-weight-bold text-info text-uppercase mb-1">
                    Payment Due
                  </div>
                  <div class="row no-gutters align-items-center">
                    <div class="col-auto">
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                        {{ paymentDue }} tk
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="font-weight-bold text-danger text-uppercase mb-1">
                    Receipt Due
                  </div>
                  <div class="h5 mb-0 font-weight-bold text-gray-800">
                    {{ receiptDue }} tk
                  </div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-comments fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Content Row -->

      <div class="row mt-5 mb-5">
        <!-- Pie Chart -->
        <pie-chart :data="productAndProject"></pie-chart>
        <label for="" class="hkf_text mx-auto" style="font-size: 1.2em !important"
          >Fig: Project Basis Sell Amount (project-sales amount)</label
        >
      </div>

      <div class="row mt-5 mb-5">
        <!-- Pie Chart -->
        <column-chart :data="timeAndProject"></column-chart>
        <label for="" class="hkf_text mx-auto" style="font-size: 1.2em !important"
          >Fig: Time Basis Sales (date-sales amount)</label
        >
        <!-- Area Chart -->
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "manager_dashboard",
  data() {
    return {
      activeGuard: "",
      purchaseAmount: 0,
      salesAmount: 0,
      paymentDue: 0,
      receiptDue: 0,
      productAndProject: [],
      timeAndProject: {},
    };
  },

  created() {
    this.activeGuard = User.getGuard();
    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "login_manager" });
    } else if (User.getGuard() == "manager") {
      this.$router.push({ name: "manager_dashboard" });
    }else{
         this.$router.push({ name: "manager_login" });
    }
    //dashboard
    axios
      .get("/api/getPurchaseAmount")
      .then((res) => {
        this.purchaseAmount = res.data;
      })
      .catch((err) => {
        console.log(err.response);
      });
    axios
      .get("/api/getSalesAmount")
      .then((res) => {
        this.salesAmount = res.data;
      })
      .catch((err) => {
      });
    axios
      .get("/api/getPaymentDue")
      .then((res) => {
        this.paymentDue = res.data;
      })
      .catch((err) => {
      });
    axios
      .get("/api/getReceiptDue")
      .then((res) => {
        this.receiptDue = res.data;
      })
      .catch((err) => {
      });
    axios.get('/api/piechart').then((res)=>{
        this.productAndProject= res.data;
    }).catch((err)=>{
    });
     axios.get('/api/areachart').then((res)=>{
        this.timeAndProject= res.data;
    }).catch((err)=>{
    });
  },
};
</script>
