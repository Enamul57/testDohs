<template>
  <!-- sidebar-->

  <div id="wrapper" v-if="authenticatedRoutes($route.name)">
    <!-- Sidebar -->
    <SidebarComponent :sideMenu="clicked" v-if="admin_sidebar"></SidebarComponent>
    <SidebarManagerComponent
      :sideMenu="clicked"
      v-else-if="manager_sidebar"
    ></SidebarManagerComponent>

    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
      <!-- Main Content -->
      <div id="content">
        <!-- Topbar -->
        <NavComponent
          @toggleButton="forSidebar"
          v-show="admin_sidebar || manager_sidebar"
        ></NavComponent>

        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid" :class="containerDynamic">
          <!-- Page Heading -->
          <router-view></router-view>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white" v-show="admin_sidebar || manager_sidebar">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span style="color: #3d388d; font-size: 1.2em"
              >Copyright &copy;HKR Website 2021</span
            >
          </div>
        </div>
      </footer>
      <!-- End of Footer -->
    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div
    class="modal fade"
    id="logoutModal"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true"
  >
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
          Select "Logout" below if you are ready to end your current session.
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">
            Cancel
          </button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>
</template>
<style></style>
<script>
import NavComponent from "../components/nav.vue";
import SidebarComponent from "../components/sidebar-component.vue";
import SidebarManagerComponent from "../components/sidebar_manager.vue";

export default {
  data() {
    return {
      clicked: false,
      activeGuard: "",

      manager_sidebar: false,
      admin_sidebar: false,
    };
  },

  components: {
    NavComponent,
    SidebarComponent,
    SidebarManagerComponent,
  },
  created() {
    this.isAuthenticated = User.hasLoggedIn();
    this.activeGuard = User.getGuard();
    this.updateSidebar();
  },
  computed: {
    validRoutes() {
      const routes = [
        "home",
        "register_admin",
        "login_admin",
        "admin_dashboard",
        "manager_dashboard",
        "login_manager",
        "register_manager",
        "add_project",
        "all_project",
        "edit_project",
        'view_project',
        'add_stage',
        'edit_stage',
        "add_client",
        "all_client",
        "view_client",
        "tin_client",
        "nid_client",
        "passport_client",
        "edit_client",
        "receipt_voucher",
        "all_voucher",
        "view_voucher",
        "edit_voucher",
        "print_voucher",
        "payment_voucher",
        "payment_all_voucher",
        "all_unit",
        "edit_unit",
        "unit",
        "add_supplier",
        "all_supplier",
        "edit_supplier",
        "payment_view_voucher",
        "payment_edit_voucher",
        "payment_print_voucher",
        "receipt_document",
        "accounts_payable",
        "accounts_receivable",
        "sales_journal",
        "purchase_journal",
        "ledger",
        "purchase_ledger",
        'apledger',
        'cash_ledger',
        'bank_ledger',
        'sales_ledger',
        'rpledger',
        'all_pay_payable',
        'edit_pay_payable',
        'pay_payable',
        'purchase_return',
        'all_purchase_return',
        'edit_purchase_return',
        'add_purchase_land',
        'edit_purchase_land',
        'all_purchase_land',
        'view_purchase_land',
        'create_sales',
        'all_sales',
        'edit_sales',
        'view_sales',
        'all_pay_receivable',
        'edit_pay_receivable',
        'pay_receivable',
        'all_expense',
        'edit_expense',
        'add_expense',
        'view_expense',
        'add_employee',
        'all_employee',
        'view_employee',
        'edit_employee',
        'pay_employee',
        'edit_salary',
        'view_salary',
        'trial_balance',
        'add_stock_journal',
        'all_stock_journal',
        'edit_stock_journal',
        'view_stock_journal',
        'add_reference',
        'edit_reference',
        'all_reference',
        'view_reference',
        'add_member',
        'edit_member',
        'all_member',
        'view_member',
        'project_base_member',
        'project_lists',
        'add_manager_approve',
        'all_manager_approve',
        'edit_manager_approve',
        'delete_manager',
        'update_password',
        'accounts_access',
      ];
      return routes;
    },
    isManager() {
      return this.manager_sidebar;
    },
    isAdmin() {
      return this.admin_sidebar;
    },
    containerDynamic() {
      return {
        container_custom:
          this.$route.path === "/manager/register" ||
          this.$route.path === "/admin/register" ||
          this.$route.path === "/admin/login" ||
          this.$route.path === "/manager/login",
      };
    },
  },

  watch: {
    $route: "updateSidebar",
    // $route: "hashchange",
  },
  methods: {
    forSidebar(data) {
      this.clicked = data;
    },
    authenticatedRoutes(routeName) {
      return this.validRoutes.includes(routeName);
    },
    updateSidebar() {
      if (User.getGuard() === "admin") {
        this.admin_sidebar = true;
        window.scrollTo(0, 0);
      } else if (User.getGuard() === "manager") {
        this.manager_sidebar = true;
        window.scrollTo(0, 0);
      } else {
        this.admin_sidebar = false;
        this.manage_sidebar = false;
        window.scrollTo(0, 0);
      }
    },
    hashchange() {
      // Scroll to the top of the page
      window.scrollTo(0, 0);
    },
  },
};
</script>
<style>
.container_custom {
  padding: 0 !important;
}
</style>
