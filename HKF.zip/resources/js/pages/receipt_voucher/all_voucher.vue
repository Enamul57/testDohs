<template>
  <div>
    <h2 class="hkf_title text-center mb-4">All Receipt Voucher</h2>
    <div class="row">
      <div class="input-group col-md-6 page_to_page">
        <router-link :to="{ name: 'receipt_voucher' }" class="btn btn-primary"
          >Create Receipt Voucher</router-link
        >
      </div>
      <div class="input-group col-md-6">
        <input
          type="search"
          v-model="searchTerm"
          class="form-control rounded"
          placeholder="Search by Dipositors name"
          aria-label="Search"
          aria-describedby="search-addon"
        />
        <button type="button" class="btn btn-primary" style="height: 38px">Search</button>
      </div>
    </div>
    <table class="table">
      <thead>
        <tr class="header_table">
          <th>SL <i class="fa fa-sort" @click="sorting_asc"></i></th>
          <th>Date</th>
          <th>FS Year</th>
          <th>Voucher No</th>
          <th>Depositors Name</th>
          <th>Paid Amount</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(receipt, index) in filterSearch">
          <td>{{ index + 1 }}</td>
          <td>{{ receipt.basic_date }}</td>
          <td>{{ receipt.financialYear }}</td>
          <td>
            {{ receipt.receipt_id }}
          </td>
          <td>
            {{ receipt.client_name }}
          </td>

          <td>
            {{ receipt.total_amount }}
          </td>

          <td class="action_td">
            <router-link
              class="btn"
              :to="{ name: 'edit_voucher', params: { id: receipt.id } }"
              ><i class="fas fa-edit"></i
            ></router-link>
            <router-link
              class="btn"
              :to="{ name: 'view_voucher', params: { id: receipt.id } }"
              ><i class="fa fa-eye"></i
            ></router-link>
            <router-link
              class="btn"
              :to="{ name: 'print_voucher', params: { id: receipt.id } }"
              ><i class="fa fa-print"></i
            ></router-link>
            <button class="btn" @click="deleteVoucher(receipt.receipt_id)">
              <i class="fa fa-trash"></i>
            </button>
          </td>
        </tr>
        <!-- add more rows as needed -->
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "all_voucher",
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
        axios.get("/api/fetch_access/" + User.getUserName()).then((res) => {
          if (User.getUserName() != res.data.manager_name) {
            vm.$router.push({ name: "manager_dashboard" });
          }
        });
      } else {
        vm.$router.push({ name: "all_voucher" });
      }
    });
  },
  data() {
    return {
      receipt_vouchers: [],
      sorting: false,
      searchTerm: "",
      isAdmin: false,
      isManager: false,
    };
  },

  methods: {
    sorting_asc() {
      this.sorting = !this.sorting;
      if (this.sorting == true) {
        return this.receipt_vouchers.sort((a, b) => {
          const nameA = a.financialYear.toUpperCase();
          const nameB = b.financialYear.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0;
        });
      } else {
        return this.receipt_vouchers.sort((a, b) => {
          const nameA = a.financialYear.toUpperCase();
          const nameB = b.financialYear.toUpperCase();
          if (nameA > nameB) {
            return -1;
          }
          if (nameA < nameB) {
            return 1;
          }
          return 0;
        });
      }
    },
    fetchReceiptVouchers() {
      if (User.getGuard() == "admin") {
        axios
          .get("/api/receipt_voucher/")
          .then((res) => {
            this.receipt_vouchers = res.data;
          })
          .catch((err) => {
            console.log(err.response);
          });
      } else if (User.getGuard() == "manager") {
        //start
        const promises= [];
        axios
          .get("/api/getManagerProject/" + User.getUserName())
          .then((res) => {
            res.data.forEach((item) => {
                promises.push(  axios.get("/api/getReceiptvouchers/" + item.project).then((res) => {
                return res.data;
              }));
            });

            Promise.all(promises).then((res)=>{
                this.receipt_vouchers = res.flat();
            })
          })
          .catch((err) => {
            console.log(err.response);
          });

          //end
      }
    },
    deleteVoucher($id) {
      axios
        .delete("/api/receipt_voucher/" + $id)
        .then((res) => {
          //reload the page
          location.reload();
        })
        .catch((err) => {
          console.log(err.response);
        });
    },
  },

  created() {
    this.fetchReceiptVouchers();
    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "home" });
    } else {
      this.$router.push({ name: "all_voucher" });
    }
  },
  computed: {
    filterSearch() {
      return this.receipt_vouchers.filter((item) => {
        const search = this.searchTerm.toLowerCase();
        const item_name = item.client_name.toLowerCase();
        return item_name.match(search);
      });
    },
  },
};
</script>
<style>
 {
  background: #a9abbf;
}
.hkf_text {
  color: #4e3089 !important;
}
th {
  font-weight: bold;
  color: #473b5edb;
}
table tr:nth-child(even) {
  background-color: #605ca8 !important;
  color: white;
}
table tr:nth-child(even) .action_td {
  background: #a9abbf;
}
.action {
  color: white;
  background: #3d388d;
  padding: 5px;
  width: 60px;
}
table tr:nth-child(odd) {
  color: #473b5edb;
  font-weight: bold;
}
.status_project {
  font-weight: bold;
  font-size: 1.2rem;
}
.text-warning {
  color: #35354c !important;
}
.text-info {
  color: #36becc !important;
}
.text-success {
  color: #228b08 !important;
}
.page_to_page {
  margin-bottom: 1rem;
}
.header_table {
  border-bottom: 1px solid #605ca8;
}
.header_table th {
  font-size: 1rem;
}
.fa-edit {
  color: #002bff;
  font-size: 1.2em;
}
.fa-eye {
  color: green;
  font-size: 1.2em;
}
th {
  font-size: 1.2em;
}
</style>
