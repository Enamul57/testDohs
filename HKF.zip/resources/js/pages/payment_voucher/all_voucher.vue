<template>
  <div>
    <h2 class="hkf_title text-center mb-4">All Puchased Voucher</h2>
    <div class="row">
      <div class="input-group col-md-6 page_to_page">
        <router-link :to="{ name: 'payment_voucher' }" class="btn btn-primary"
          >Create Purchase Voucher</router-link
        >
      </div>

      <div class="input-group col-md-6">
        <input
          type="search"
          v-model="searchTerm"
          class="form-control rounded"
          placeholder="Search By Supplier Name/ Land Daag No.."
          aria-label="Search"
          aria-describedby="search-addon"
        />
        <button type="button" class="btn btn-primary" style="height: 38px">Search</button>
      </div>
      <div class="col-md-4 mb-2">
        <label for="projectName" class="hkf_text">Search Type</label>
        <select
          class="form-control"
          id="status"
          name="status"
            @change='selectedSearch'
          v-model="selectedSearchType"
          required
        >
          <option
            v-for="(search_type, index) in search_types"
            :key="index"
            :value="search_type.value"
          >
            {{ search_type.label }}
          </option>
        </select>
      </div>
    </div>
    <table class="table">
      <thead>
        <tr class="header_table">
          <th>SL <i class="fa fa-sort" @click="sorting_asc"></i></th>
          <th>Date</th>
          <th>FS Year</th>
          <th>Voucher No</th>
          <th>Supplier's Name</th>
          <th>Net Amount</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(payment, index) in filterSearch">
          <td>{{ index + 1 }}</td>
          <td>{{ payment.basic_date }}</td>
          <td>{{ payment.financialYear }}</td>
          <td>
            {{ payment.payment_id }}
          </td>
          <td>
            {{ payment.payee_name }}
          </td>

          <td>
            {{ payment.total_amount }}
          </td>

          <td class="action_td">
            <router-link
              class="btn"
              :to="{ name: 'payment_edit_voucher', params: { id: payment.id } }"
              ><i class="fas fa-edit"></i
            ></router-link>
            <router-link
              class="btn"
              :to="{ name: 'payment_view_voucher', params: { id: payment.id } }"
              ><i class="fa fa-eye"></i
            ></router-link>
            <router-link
              class="btn"
              :to="{ name: 'payment_print_voucher', params: { id: payment.id } }"
              ><i class="fa fa-print"></i
            ></router-link>
            <button class="btn" @click="deleteVoucher(payment.payment_id)">
              <i class="fa fa-trash"></i>
            </button>
          </td>
        </tr>
        <!-- add more rows as needed -->
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "payment_all_voucher",
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
         axios.get("/api/fetch_access/" + User.getUserName()).then((res) => {
          if (User.getUserName() != res.data.manager_name) {
            vm.$router.push({ name: "manager_dashboard" });
          }
        });
      } else {
        vm.$router.push({ name: "payment_all_voucher" });
      }
    });
  },
  data() {
    return {
      payment_vouchers: [],
      sorting: false,
      searchTerm: "",
      selectedSearchType: "",
      search_types: [
        { label: "Land", value: "Land" },
        { label: "Others", value: "Others" },
      ],
      search_name: "",
      searchLand:false,
    };
  },

  methods: {
    sorting_asc() {
      this.sorting = !this.sorting;
      if (this.sorting == true) {
        return this.payment_vouchers.sort((a, b) => {
          const nameA = a.financialYear.toUpperCase();
          const nameB = b.financialYear.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0;
        });
      } else {
        return this.payment_vouchers.sort((a, b) => {
          const nameA = a.financialYear.toUpperCase();
          const nameB = b.financialYear.toUpperCase();
          if (nameA > nameB) {
            return -1;
          }
          if (nameA < nameB) {
            return 1;
          }
          return 0;
        });
      }
    },
    fetchReceiptVouchers() {
     if(User.getGuard()=='admin'){
         axios
        .get("/api/payment_voucher/")
        .then((res) => {
          this.payment_vouchers = res.data;
        })
        .catch((err) => {
        });
     }else if(User.getGuard()=='manager'){
        const promises = [];
         axios
          .get("/api/getManagerProject/" + User.getUserName())
          .then((res) => {
            res.data.forEach((item) => {
            promises.push(  axios.get("/api/getPaymentvouchers/" + item.project).then((res) => {
              return res.data;
              }));
            });

            Promise.all((promises)).then((res)=>{
                this.payment_vouchers = res.flat();
            })
          })
          .catch((err) => {
          });
     }
    },

    deleteVoucher($id) {
      axios
        .delete("/api/payment_voucher/" + $id)
        .then((res) => {
          //reload the page
          location.reload();
        })
        .catch((err) => {
        });
    },
  },

  created() {
    this.fetchReceiptVouchers();
  },
  computed: {
    selectedSearch() {
        if (this.selectedSearchType == "Land" ) {
         this.searchLand = true;
        }else{
            this.searchLand = false;
        }
    },
    filterSearch() {
      return this.payment_vouchers.filter((item) => {
        const search = this.searchTerm.toLowerCase();

        if (!this.searchLand) {
          const item_name = item.payee_name.toLowerCase();
          return item_name.match(search);
        } else if (this.searchLand
        ) {


          const item_name3 = item.ledger_no;

          return item_name3.includes(search);
        }
      });
    },
  },
};
</script>
<style>
 {
  background: #a9abbf;
}
.hkf_text {
  color: #4e3089 !important;
}
th {
  font-weight: bold;
  color: #473b5edb;
}
table tr:nth-child(even) {
  background-color: #605ca8 !important;
  color: white;
}
table tr:nth-child(even) .action_td {
  background: #a9abbf;
}
.action {
  color: white;
  background: #3d388d;
  padding: 5px;
  width: 60px;
}
table tr:nth-child(odd) {
  color: #473b5edb;
  font-weight: bold;
}
.status_project {
  font-weight: bold;
  font-size: 1.2rem;
}
.text-warning {
  color: #35354c !important;
}
.text-info {
  color: #36becc !important;
}
.text-success {
  color: #66a756  !important;
}
.page_to_page {
  margin-bottom: 1rem;
}
.header_table {
  border-bottom: 1px solid #605ca8;
}
.header_table th {
  font-size: 1rem;
}
.fa-edit {
  color: #002bff;
  font-size: 1.2em;
}
.fa-trash {
  color: #d33a3a;
  font-size: 1.2em;
}
.fa-eye {
  color: green;
  font-size: 1.2em;
}
th {
  font-size: 1.2em;
}
</style>
