<template>
  <div>
    <h2 class="hkf_title text-center mb-4">Expenses</h2>
    <div class="row">
      <div class="input-group col-md-6 page_to_page">
        <router-link :to="{ name: 'add_expense' }" class="btn btn-primary"
          >Add Expense</router-link
        >
      </div>
      <div class="input-group col-md-6">
        <input
          type="search"
          v-model="searchTerm"
          class="form-control rounded"
          placeholder="Search by cost name"
          aria-label="Search"
          aria-describedby="search-addon"
        />
        <button type="button" class="btn btn-primary" style="height: 38px">Search</button>
      </div>

    </div>
     <form @submit.prevent="totalExpense()" class="mt-5">
        <div class="form-row">


          <div class="form-group col-md-3">
            <label for="" class="hkf_text">Start Date</label>
            <input
              type="date"
              v-model="startDate"
              class="form-control rounded"
              aria-label="Search"
              aria-describedby="search-addon"
              required
            />
          </div>
          <div class="form-group col-md-3">
            <label for="" class="hkf_text">End Date</label>
            <input
              type="date"
              v-model="endDate"
              class="form-control rounded"
              aria-label="Search"
              aria-describedby="search-addon"
              required
            />
          </div>
          <div class="form-group col-md-3" style="margin-top: 30px">
            <button type="submit" class="btn btn-primary" style="height: 38px">
              Calculate Total Expense
            </button>
          </div>

        </div>
         <div class=" col-md-6">
            <label for="" class='col-form-label hkf_text'>Total Expense (All Project Base):  {{this.total_expense}}</label>
            </div>
      </form>
    <table class="table">
      <thead>
        <tr>
          <th>Cost Name <i class="fa fa-sort" @click="sorting_asc"></i></th>
          <th>Payment Type</th>
          <th>Cost Amount</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="project in filterSearch">
          <td>{{ project.product_name }}</td>
          <td>{{ project.selectedPaymentType }}</td>
          <td>
            {{ project.receive_amount }} Tk
          </td>

          <td class="remove_bg_td">
            <router-link
              class="action btn"
              :to="{ name: 'edit_expense', params: { id: project.id } }"
              >Edit</router-link
            >
            <router-link
              class="action btn ml-2"
              :to="{ name: 'view_expense', params: { id: project.id } }"
              >View</router-link
            >

          </td>
        </tr>

        <!-- add more rows as needed -->
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "all_expense",
  data() {
    return {
      projects: [],
      sorting: false,
      searchTerm: "",
      startDate:"",
      endDate:"",
      total_expense:"",
    };
  },
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      }else {
        vm.$router.push({ name: "all_expense" });
      }
    });
  },
  methods: {
    sorting_asc() {
      this.sorting = !this.sorting;
      if (this.sorting == true) {
        return this.projects.sort((a, b) => {
          const nameA = a.product_name.toUpperCase();
          const nameB = b.product_name.toUpperCase();
          if (nameA >nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0;
        });
      } else {
        return this.projects.sort((a, b) => {
          const nameA = a.product_name.toUpperCase();
          const nameB = b.product_name.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA < nameB) {
            return 1;
          }
          return 0;
        });
      }
    },
    fetchProjects(url) {
           //admin  & manager
    this.guard = User.getGuard();
    if (this.guard == "admin") {
      this.admin = true;
      this.manager = false;

       axios
        .get(url)
        .then((res) => {
          this.projects = res.data;
        })
        .catch((error) => {
        });
    } else if (this.guard == "manager") {
      this.manager = true;
      this.admin = false;
      this.manager_username = User.getUserName();
      axios
        .get("/api/getManagerProject/" + this.manager_username)
        .then((res) => {
           res.data.forEach((item)=>{
            axios.get('/api/manager_fetch_expense/'+item.project).then((res)=>{
                this.projects=res.data;
            });
           });
        })
        .catch((err) => {
        });
    }
    //end

    },
    totalExpense(){
        const requestData = {
            startDate : this.startDate,
            endDate: this.endDate,
        };
        axios.post('/api/expense/totalExpense',requestData).then((res)=>{
           this.total_expense = res.data.totalExpense;
        }).catch((err)=>{
            console.log(err.response);
        })
    }
  },
  created() {
    this.fetchProjects("/api/expense/");
  },
  computed: {
    filterSearch() {
      return this.projects.filter((project) => {
        const search_Term = this.searchTerm.toLowerCase();
        const typeName = project.product_name.toLowerCase();
        return typeName.match(search_Term);
      });
    },
  },
};
</script>
<style>
.hkf_text {
  color: #4e3089 !important;
}
th {
  font-weight: bold;
  color: #473b5edb;
}
table tr:nth-child(even) {
  background-color: #605ca8 !important;
  color: white;
}
.action {
  color: white;
  background: #5d57c3;
  padding: 5px;
  width: 60px;
}
table tr:nth-child(odd) {
  color: #473b5edb;
  font-weight: bold;
}
.status_project {
  font-weight: bold;
  font-size: 1.2rem;
}
.text-warning {
  color: #35354c !important;
}
.text-info {
  color: #36becc !important;
}
.text-success {
  color: #66a756 !important;
}
.page_to_page {
  margin-bottom: 1rem;
}
table tr:nth-child(even) .remove_bg_td {
  background: white;
}
</style>
