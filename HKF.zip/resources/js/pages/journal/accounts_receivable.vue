<template>
  <div>
    <h2 class="text-center mb-4 hkf_title">Accounts Receivable</h2>

    <div class="row">
      <div class="col-md-12" style="display: flex">
        <div class="col-md-8">
          <button
            type=" button"
            @click="showAll"
            class="action btn mx-auto mb-5"
            style="width: 50%; padding: 0.5rem"
          >
            Show All Receivable
          </button>
        </div>
        <div class="col-md-4">
          <label class="hkf_text">Search Accounts Receivable By Date:</label>
          <input
            type="date"
            class="form-control"
            placeholder="Enter Cheque Date"
            @change="selectDate"
            v-model="sendDate"
          />
        </div>
      </div>

      <table style="width: 100%; margin-bottom: 1rem">
        <tbdoy v-for="(receipt_journal,index) in receipt_journals">
          <div style='display:flex' class='mb-2'>
            <div class='col-md-6' >
        <h6 class='hkf_text' style='list-style:square'>{{index+1}}</h6>
        </div>
        <div class='col-md-6 text-right' >
          <button type="button" class='action btn' @click="getUrlID(receipt_journal.receipt_id)">View</button>
        </div>
          </div>
          <tr style="border: 1px solid black; border-collapse: collapse">
            <th
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 4%;
                color:white;
              "
            >
              Sl
            </th>
            <th
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
                 color:white;
              "
            >
              Particular
            </th>
            <th
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%; color:white;
              "
            >
              Cost Center
            </th>
            <th
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%; color:white;
              "
            >
              Debit
            </th>
            <th
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%; color:white;
              "
            >
              Credit
            </th>
          </tr>

          <tr style="padding: 1rem; border: 1px solid black; border-collapse: collapse">
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 4%;
              "
            >
              1
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ receipt_journal.client_name }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ receipt_journal.project }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(receipt_journal.due).toFixed(2) }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(0).toFixed(2) }}
            </td>
          </tr>
          <tr style="padding: 1rem; border: 1px solid black; border-collapse: collapse">
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 4%;
              "
            >
              2
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
            {{receipt_journal.product_name}}
            </td>

            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ receipt_journal.project }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(0).toFixed(2) }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(receipt_journal.paid).toFixed(2) }}
            </td>
          </tr>
          <tr style="padding: 1rem; border: 1px solid black; border-collapse: collapse">
            <td
              style="
                padding: 1rem;

                text-align: center;
                width: 4%;
              "
            >

            </td>
            <td
              style="
                padding: 1rem;

                text-align: center;
                width: 24%;
              "
            >
              Total
            </td>
            <td
              style="
                padding: 1rem;

                text-align: center;
                width: 24%;
              "
            ></td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(receipt_journal.due).toFixed(2) }}
            </td>
            <td
              style="
                padding: 1rem;
                border: 1px solid black;
                text-align: center;
                width: 24%;
              "
            >
              {{ parseFloat(receipt_journal.paid).toFixed(2) }}
            </td>
          </tr>
          <hr />
        </tbdoy>
      </table>
      <div style='width:100%;text-align:center;'>
        <h3 v-if="empty" style='color:red;'>{{ this.msg }}</h3>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "sales_journal",
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
          axios.get("/api/fetch_access/" + User.getUserName()).then((res) => {
          if (User.getUserName() != res.data.manager_name) {
            vm.$router.push({ name: "manager_dashboard" });
          }
        });
      } else {
        vm.$router.push({ name: "accounts_receivable" });
      }
    });
  },
  data() {
    return {
      sendDate: "",
      receipt_journals: [],
      temp: [],
      msg: "",
      empty: false,
    };
  },
  created() {

  },
  methods: {
    getUrlID($receipt_id){
        axios.get('/api/receipt_journal/getID/'+$receipt_id).then((res)=>{
          let id = res.data.id;

          this.$router.push({name:"view_voucher",params:{id:id}})
        }).catch((err)=>{
        });
    },
    showAll() {
      axios
        .get("/api/accounts_receivable/")
        .then((res) => {

          const purchase = res.data;
          this.empty = false;
          this.receipt_journals = [];
          purchase.forEach((item) =>
          {
            if (parseInt(item.product_amount) != parseInt(item.paid)) {
              this.receipt_journals.push(item);
            }
          });
        })
        .catch((err) => {
        });
    },
  },
  computed: {
    selectDate() {
      axios
        .get("/api/accounts_receivable/daily_journal/" + this.sendDate)
        .then((res) => {
          this.receipt_journals = [];
          this.empty = false;
          res.data.forEach((item) => {
            if (item) {

                this.receipt_journals.push(item);

            }
          });
          if (res.data.Empty) {
            this.empty = true;
            this.msg = res.data.Empty;
          }
        })
        .catch((err) => {
           this.empty = true;
            this.msg = "There is no receipt journal in this date";
        });
    },
  },
};
</script>
<style>
.formBox {
  border: 1px solid #4e3089;
  margin: 1rem;
  box-sizing: border-box;
  width: 100%;
}
.depositorBox {
  font-size: 0.85em;
}
.box_container {
  display: flex;
}
.title_col {
  width: 60%;
}
.plusBtn {
  width: 100%;
  display: flex;
}
.plusSection {
  width: 100%;
  display: flex;
}
.faBtn {
  text-align: right;
  margin-top: 3em;
  padding-right: 3%;
  margin-bottom: 1em;
}
.faBtnCross button {
  background: red;
  margin-top: 2em;
  color: white;
  border: none;
  border-radius: 10%;
}
.faBtn button {
  background: #5252d7;
  color: white;
  border: none;
  border-radius: 10%;
}
.cashSection {
  padding: 2rem 0;
}
.additionalPart {
  width: 100%;
  color: black;
  margin: 1rem 2rem;
}
.two_group {
  display: flex;
}
.pjtable {
}
@media only screen and (max-width: 900px) {
  .title_col {
    width: 100%;
  }
}
</style>
