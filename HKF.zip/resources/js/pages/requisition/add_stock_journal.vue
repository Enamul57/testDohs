<template>
  <div>
    <h2 class="text-center mb-4 hkf_title">Add Stock Valuation</h2>
    <div class="input-group col-md-6 page_to_page">
      <router-link :to="{ name: 'all_stock_journal' }" class="btn btn-primary"
        >All Stock Valuation</router-link
      >
    </div>
    <div class="row">
      <div class="col-md-6">
        <form class="form" @submit.prevent="addAccountHead()">
          <div class="form-group mx-sm-3 mb-2">
            <label class="hkf_text">Select Product</label>
            <select
              class="form-control status"
              id="status"
              v-model="form.product_name"
              required
              @change="chooseProduct"
            >
              <option
                v-for="(product, index) in products"
                :key="index"
                :value="product.product_name"
              >
                {{ product.product_name }}
              </option>
            </select>
          </div>
          <div class="form-group mx-sm-3 mb-2" v-if="admin">
                <label for="projectName" class="hkf_text">Select Project</label>
                <select
                  class="form-control status"
                  id="status"
                  v-model="form.selectedProject"
                  required
                >
                  <option
                    v-for="(project, index) in allProjects"
                    :key="index"
                    :value="project.project_name"
                  >
                    {{ project.project_name }}
                  </option>
                </select>
              </div>
              <div class="form-group mx-sm-3 mb-2" v-if="manager">
                <label for="projectName" class="hkf_text">Select Project</label>
                <select
                  class="form-control status"
                  id="status"
                  v-model="form.selectedProject"
                  required
                >
                  <option
                    v-for="(project, index) in allProjects"
                    :key="index"
                    :value="project.project"
                  >
                    {{ project.project }}
                  </option>
                </select>
              </div>
          <div class="form-group mx-sm-3 mb-2">
            <label class="hkf_text">Total Quantity</label>
            <input
              type="text"
              class="form-control"
              placeholder="Total Quantity"
              v-model="form.total_quantity"
              required disabled
            />
          </div>
          <div class="form-group mx-sm-3 mb-2">
            <label class="hkf_text">Consume Quantity</label>
            <input
              type="text"
              class="form-control"
              placeholder="Consume Quantity"
              v-model="form.consumeQuantity" @keyup='calculate'
              required
            />
          </div>
          <div class="form-group mx-sm-3 mb-2">
            <label class="hkf_text">Description</label>
            <input
              type="text"
              class="form-control"
              placeholder="Description.."
              v-model="form.Description"

            />
          </div>

          <button type="submit" class="btn btn-primary mb-2" v-if='!hideButton'>Save</button>
        </form>
        <small class="text text-danger" v-if="errors.type_name">{{
          errors.type_name[0]
        }}</small>
        <small class="text text-danger" v-if="hideButton">{{
          msg
        }}</small>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "add_account_type",

  data() {
    return {
      form: {
        product_name: "",
        selectedProject: "",
        total_quantity: "",
        consumeQuantity: "",
        Description: "",
        notification:1,
      },
      hideButton:false,
      msg:"",
      projects: [],
      products:[],
      errors: {},
      allProjects:[],
    };
  },
  created() {
    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "home" });
    } else {
      this.$router.push({ name: "add_stock_journal" });
    }
    axios
      .get("/api/stock_journal/")
      .then((res) => {
        this.products = res.data;
      })
      .catch((err) => {
        console.log(err.response);
      });
        //admin  & manager
    this.guard = User.getGuard();
    if(this.guard =='admin'){
        this.admin = true;
        this.manager = false;
         axios
          axios
      .get("/api/project/")
      .then((res) => {
        this.allProjects = res.data;
      })
      .catch((err) => {
        console.log(err);
      });
    }else if(this.guard =='manager'){
        this.manager = true;
        this.admin=false;
        this.manager_username = User.getUserName();
        axios.get('/api/getManagerProject/'+this.manager_username).then((res)=>{
            this.allProjects = res.data;
        }).catch((err)=>{
            console.log(err.response);
        });
    }
        //end
  },
  methods: {
    addAccountHead() {
      axios
        .post("/api/requisition", this.form)
        .then((res) => {
          this.$router.push({ name: "all_stock_journal" });
        })
        .catch((error) => {
          this.errors = JSON.parse(error.response.data);
        });
    },
  },
  computed: {
    chooseProduct(){
       axios.get('/api/fetchStock/'+this.form.product_name).then((res)=>{
        this.form.total_quantity = res.data.total_quantity;
       }).catch((err)=>{
        console.log(err.response);
       })
    },
    calculate(){
        if(parseInt(this.form.total_quantity)< parseInt(this.form.consumeQuantity)){
            this.hideButton = true;
            this.msg = "Consumed quantity can't  be greater than total quantity";
        }else{
            this.hideButton = false;
            this.msg = "";

        }
    }
  },
};
</script>
