<template>
  <div>
    <h2 class="hkf_title text-center mb-4">Stocks</h2>
    <div class="row">
      <div class="input-group col-md-6 page_to_page">

      </div>
    </div>
    <table class="table">
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Quantity</th>
          <th>Unit</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="account_head in account_heads" :key="account_head.id">
          <td>{{ account_head.product_name }}</td>

          <td>
            {{ account_head.total_quantity }}
          </td>
          <td>
            {{ account_head.unit }}
          </td>
        </tr>

        <!-- add more rows as needed -->
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "all_project",
  data() {
    return {
      account_heads: [],
      sorting: false,
      searchTerm: "",
    };
  },

  methods: {
    fetchProjects() {
      axios
        .get("/api/stock_journal")
        .then((res) => {
          this.account_heads = res.data;
          this.account_heads.forEach((eachProduct, index) => {
            axios
              .get("/api/getUnit/" + eachProduct.product_name)
              .then((res) => {
                this.account_heads[index].unit = res.data.item_unit;
              })
              .catch((err) => {});
          });
        })
        .catch((error) => {
          console.log(error);
        });
    },
    deleteStock($id) {
      axios
        .delete("/api/requisition/" + $id)
        .then((res) => {
          location.reload();
        })
        .catch((err) => {
          console.log(err.response);
        });
    },
    // setPage(page) {
    //   this.currentPage = page;
    //   this.fetchProjects();
    // },
  },
  created() {
    this.fetchProjects();
  },
  computed: {},
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else {
        vm.$router.push({ name: "view_stock_journal" });
      }
    });
  },
};
</script>
<style>
.hkf_text {
  color: #4e3089 !important;
}
th {
  font-weight: bold;
  color: #473b5edb;
}
table tr:nth-child(even) {
  background-color: #605ca8 !important;
  color: white;
}
.action {
  color: white;
  background: #5d57c3;
  padding: 5px;
  width: 60px;
}
table tr:nth-child(odd) {
  color: #473b5edb;
  font-weight: bold;
}
.status_project {
  font-weight: bold;
  font-size: 1.2rem;
}
.text-warning {
  color: #35354c !important;
}
.text-info {
  color: #36becc !important;
}
.text-success {
  color: #63cb49 !important;
}
.page_to_page {
  margin-bottom: 1rem;
}
table tr:nth-child(even) .remove_bg_td {
  background: white;
}
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.pagination li {
  list-style: none;
  margin: 0 5px;
  display: inline;
}

.pagination li.active a {
  color: #ffffff;
  background-color: #007bff;
  border: 1px solid #007bff;
}

.pagination li a {
  color: #007bff;
  background-color: #ffffff;
  border: 1px solid #007bff;
  padding: 6px 12px;
  text-decoration: none;
  cursor: pointer;
  margin-right: 5px;
}
.pagination li a :hover {
  background-color: #007bff;
  color: #ffffff;
}
</style>
