<template>
  <div>
    <h3 class="hkf_title text-center mb-4">Cash Ledger</h3>
    <div>
      <nav>
        <ol class="nav ledger_nav_inline">
          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'purchase_ledger' }"
              >Purchase Ledger</router-link
            >
          </li>
          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'sales_ledger' }"
              >Sales Ledger</router-link
            >
          </li>
          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'apledger' }"
              >Accounts Payable Ledger</router-link
            >
          </li>
          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'rpledger' }"
              >Accounts Receivable Ledger</router-link
            >
          </li>
          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'cash_ledger' }"
              >Cash Ledger</router-link
            >
          </li>

          <li class="nav-item ledger_li_inline">
            <router-link class="ledger_link" :to="{ name: 'bank_ledger' }">
              Bank Ledger</router-link
            >
          </li>
        </ol>
      </nav>
    </div>
    <button
      type="button"
      class="btn action_print"
      style="margin-left: 85%"
      @click="printContent"
    >
      Print<i class="fa fa-print pl-2" aria-hidden="true"></i>
    </button>
    <div>
      <form @submit.prevent="passLedger()" class="mt-5">
        <div class="form-row">
          <div class="form-group col-md-3">
            <label for="projectName" class="hkf_text">Select Product</label>
            <select
              class="form-control status"
              id="status"
              v-model="selectedLedger"
              required
              onfocus="this.size=3"
              onblur="this.size=1"
              onchange="this.size=1;this.blur();"
            >
              <option
                v-for="(allLedger, index) in allLedgers"
                :key="index"
                :value="allLedger.product_name"
              >
                {{ allLedger.product_name }}
              </option>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label for="projectName" class="hkf_text">Select Supplier</label>
            <select
              class="form-control status"
              id="status"
              v-model="selectedSupplier"
              onfocus="this.size=3;"
              onblur="this.size=1;"
              onchange="this.size=1; this.blur();"
            >
              <option :value="all_supplier">All</option>
              <option
                v-for="(allSupplier, index) in allSuppliers"
                :key="index"
                :value="allSupplier.supplier_name"
              >
                {{ allSupplier.supplier_name }}
              </option>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label for="" class="hkf_text">Start Date</label>
            <input
              type="date"
              v-model="startDate"
              class="form-control rounded"
              aria-label="Search"
              aria-describedby="search-addon"
              required
            />
          </div>
          <div class="form-group col-md-3">
            <label for="" class="hkf_text">End Date</label>
            <input
              type="date"
              v-model="endDate"
              class="form-control rounded"
              aria-label="Search"
              aria-describedby="search-addon"
              required
            />
          </div>
          <div class="form-group col-md-8" style="margin-top: 30px">
            <button type="submit" class="btn btn-primary" style="height: 38px">
              Search
            </button>
          </div>
        </div>
      </form>

      <div id="print-container">
      <div style='display:flex'>
          <div class="sidebar-brand-icon" style='text-align:left;width:20%;'>
        <img class="logo" src="/img/logo.png" style='width:165%;height:77%;' alt="" />
      </div>
       <div style='padding:5%;width:80%;'>
        <h3 style="text-align: center;">HKF Real Estate LTD</h3>
              <h4 style="text-align: center">
                117/2/8 1st Floor Sopnodanga Residential Area<br>
                Phone: 01400407270  <br>    Email:contact@hkf-re.com <br>
                Website: www.hkf-re.com
              </h4>
      </div>
      </div>
        <label class="hkf_text"> Date: {{ startDate }} - {{ endDate }} </label>
        <label class="hkf_text"> Particular: {{ selectedLedger}} </label>

        <table class="table custom_table"  style='width:100%; border: 1px solid black;border-collapse: collapse; text-align:center;'>
          <thead class="thead" style="height: 70px">
            <tr>
              <th scope="col"  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                Date
              </th>
              <th scope="col"  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                Particular
              </th>

              <th scope="col"  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                Debit(TK)
              </th>
              <th scope="col"  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                Credit(TK)
              </th>
              <th
                scope="col"
                style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
              >
                Balance
              </th>
            </tr>
          </thead>

          <tbody >
            <tr v-for="(ap_ledger, index) in ap_ledgers">
              <td scope="row"  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                {{ ap_ledger.date }}
              </td>
              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-if="ap_ledger.payment_status == 0"
              >
                {{ ap_ledger.supplier_name }},{{ ap_ledger.product_name }}
              </td>
              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-else-if="ap_ledger.payment_status == 1"
              >
                {{ ap_ledger.product_name }}
              </td>
              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-if="ap_ledger.return_amount != null"
              >
                {{ ap_ledger.return_amount }}
              </td>
              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-else-if="ap_ledger.receipt_paid != null"
              >
                {{ ap_ledger.receipt_paid }}
              </td>

              <td  style=' border: 1px solid black;border-collapse: collapse; text-align:center;' v-else></td>

              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-if="ap_ledger.paid != null"
              >
                {{ Math.abs(ap_ledger.paid) }}
              </td>
              <td
                 style=' border: 1px solid black;border-collapse: collapse; text-align:center;'
                v-else-if="ap_ledger.paid == null"
              ></td>

              <td  style=' border: 1px solid black;border-collapse: collapse; text-align:center;'>
                {{ ap_ledger.balance }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <!-- <h6 style='color:black;font-weight:bold;text-align:right;width:88%;'>Balance = {{this.sumOfBalance[i]}}</h6> -->
  </div>
</template>

<script>
export default {
  name: "apledger",

  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
        axios.get("/api/fetch_access/" + User.getUserName()).then((res) => {
          if (User.getUserName() != res.data.manager_name) {
            vm.$router.push({ name: "manager_dashboard" });
          }
        });
      } else {
        vm.$router.push({ name: "cash_ledger" });
      }
    });
  },
  data() {
    return {
      ap_ledgers: [],
      selectedLedger: "",
      allLedgers: [],
      startDate: "",
      endDate: "",
      selectedSupplier: "",
      allSuppliers: [],
    };
  },
  created() {
    axios.get("/api/cash_suppliers").then((res) => {
      this.allSuppliers = res.data;
    });
    axios
      .get("/api/cash_ledger")
      .then((res) => {
        this.allLedgers = res.data;
      })
      .catch((err) => {
      });
  },

  methods: {
    passLedger() {
      const requestData = {
        product_name: this.selectedLedger,
        startDate: this.startDate,
        endDate: this.endDate,
        supplier_name: this.selectedSupplier,
      };
      axios
        .post("/api/cash_ledger/pass_ldg", requestData)
        .then((res) => {
          this.ap_ledgers = res.data;
        })
        .catch((err) => {
        });
    },

    printContent() {
      const printContents = document.getElementById("print-container").innerHTML;
      const originalContents = document.body.innerHTML;
      const popupWin = window.open("width=800,height=800");
      popupWin.document.open();
      popupWin.document.write(`
        <html>
          <head>
            <style>
              /* Your styles go here */
              *{
                padding:0.25rem;

              }
              .custom_table,thead,th,tr,td{
                border:1px solid black;
              }

            </style>
          </head>
          <body onload="window.print();window.close();">${printContents}</body>
        </html>
      `);
      popupWin.document.close();
      this.$router.push({
        name: "cash_ledger",
      });
    },
  },
};
</script>

<style>
.custom_table tr:nth-child(even) {
  background-color: white !important;
  color: black;
  font-weight: bold;
}
.custom_table tr:nth-child(odd) {
  color: black;
  font-weight: bold;
}
.custom_table th {
  border: 1px solid black;
}
.fixHeight {
  height: 120px;
  overflow-y: scroll;
}
select {
  width: 100%;
  height: 100%;
  font-size: 16px;
}
@media only screen and (min-width: 601px) and (max-width: 979px) {
  .margin_remover {
    margin-left: 0%;
    width: 80%;
  }
  .custom_table th {
    font-size: 0.9em;
  }
  .custom_table td {
    font-size: 0.8em;
  }
}

@media only screen and (min-width: 980px) {
  .margin_remover {
    margin-left: 10%;
  }
  .custom_table th {
    font-size: 1em;
  }
  .custom_table td {
    font-size: 1em;
  }
}
@media only screen and (max-width: 600px) {
  .custom_table th {
    font-size: 0.8em;
  }
  .custom_table td {
    font-size: 0.8em;
  }
}
</style>
