<template>
  <div>
    <h2 class="text-center mb-4 hkf_title">Add Project</h2>
    <div class="input-group col-md-6 page_to_page">
      <router-link :to="{ name: 'all_project' }" class="btn btn-primary"
        >All Project</router-link
      >
    </div>
    <div class="row">
      <div class="col-md-12 mx-auto">
        <form @submit.prevent="addProject()">
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="projectName" class="hkf_text">Project Name</label>
            <input
              type="text"
              class="form-control"
              placeholder="Project Name"
              v-model="form.project_name"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Location</label>
            <input
              type="text"
              class="form-control"
              placeholder="Location"
              v-model="form.project_address"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label class="hkf_text">Status</label>
            <select class="form-control" v-model="form.project_status" required>
              <option
                v-for="(option, index) in options"
                :key="index"
                :value="option.value"
              >
                {{ option.label }}
              </option>
            </select>
          </div>
          <!-- -->
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Contact Number</label>
            <input
              type="text"
              class="form-control"
              placeholder="Contact Number"
              v-model="form.contact_number"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Land Amount</label>
            <input
              type="text"
              class="form-control"
              placeholder="Land Amount"
              v-model="form.land_amount"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Building Height</label>
            <input
              type="text"
              class="form-control"
              placeholder="Building Height"
              v-model="form.building_height"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Average Flat Size</label>
            <input
              type="text"
              class="form-control"
              placeholder="Average Flat Size"
              v-model="form.average_flat_size"
              required
            />
          </div>
          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Floor Area Size</label>
            <input
              type="text"
              class="form-control"
              placeholder="Flat Area Size"
              v-model="form.flore_area_size"
              required
            />
          </div>

          <div class="form-group mx-sm-3 col-md-6 mb-2">
            <label for="location" class="hkf_text">Logo</label>
            <input
              type="file"
              class="form-control-file col-md-4"
              @change="nidFileSelected"
            />
            <div class="col-md-4">
              <td>
                <img :src="logo" alt="" style="width: 50%; height: auto" />
              </td>
            </div>
          </div>
          <div class="form-group mx-sm-3 col-md-6">
            <label for="location" class="hkf_text">Architact Drawing File</label>
            <input
              type="file"
              class="form-control-file col-md-4"
              @change="selectedDocs"
            />
            <div class="col-md-12 text-right">
              <button type="submit" class="btn btn-primary mb-2">Save</button>
            </div>
            <embed :src="Supporting_docs" type="application/pdf" />
          </div>

          <!-- -->
        </form>
        <small class="text text-danger" v-if="errors.project_name">{{
          errors.project_name[0]
        }}</small>
        <small class="text text-danger" v-if="errors.project_address">{{
          errors.project_address[0]
        }}</small>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "add_project",

  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
        vm.$router.push({ name: "manager_dashboard" });
      } else {
        vm.$router.push({ name: "add_project" });
      }
    });
  },
  data() {
    return {
      logo: "",
      form: {
        project_name: "",
        project_address: "",
        project_status: "",
        logo: "",
        contact_number: "",
        land_amount: "",
        average_flat_size: "",
        flore_area_size: "",
        building_height: "",
        architact_drawing: "",
      },
      Supporting_docs: "",
      options: [
        { value: "in-progress", label: "In Progress" },
        { value: "completed", label: "Completed" },
        { value: "on-hold", label: "On Hold" },
        { value: "upcoming", label: "Upcoming" },
      ],
      errors: {},
    };
  },
  methods: {
    addProject() {
      const formData = new FormData();
      formData.append("project_name", this.form.project_name);
      formData.append("project_address", this.form.project_address);
      formData.append("project_status", this.form.project_status);
      formData.append("logo", this.form.logo);
      formData.append("contact_number", this.form.contact_number);
      formData.append("land_amount", this.form.land_amount);
      formData.append("average_flat_size", this.form.average_flat_size);
      formData.append("flore_area_size", this.form.flore_area_size);
      formData.append("building_height", this.form.building_height);
      formData.append("architact_drawing", this.form.architact_drawing);
      axios
        .post("/api/project", formData, {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        })
        .then((res) => {
          this.$router.push({ name: "all_project" });
        })
        .catch((error) => {
          this.errors = JSON.parse(error.response.data);
        });
    },
    nidFileSelected(event) {
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.logo = event.target.result;
        this.form.logo = file;
      };
      reader.readAsDataURL(file);
    },
    selectedDocs() {
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.Supporting_docs = event.target.result;
        this.form.architact_drawing = file;
      };

      reader.readAsDataURL(file);
    },
  },
};
</script>
<style>
label {
  margin-right: 1em;
}
.hkf_text {
  color: #000000cf !important;
  font-weight: bold;
}
.hkf_title {
  color: #605ca8 !important;
  border-bottom: 1px solid #554e6a;
}
#status {
  color: black;
}

#status option:active {
  background-color: #6e6c8b !important;
  color: #fff;
}
.text-danger {
  color: #e74a3b !important;
  font-size: 1em;
}
</style>
