<template>
  <div>
    <h2 class="hkf_title text-center mb-4 ">All Project</h2>
    <div class="row">
      <div class="input-group col-md-6 page_to_page">
        <router-link :to="{ name: 'add_project' }" class="btn btn-primary"
          >Add Project</router-link
        >
      </div>
      <div class="input-group col-md-6">
        <input
          type="search"
          v-model="searchTerm"
          class="form-control rounded"
          placeholder="Search by location"
          aria-label="Search"
          aria-describedby="search-addon"
        />
        <button type="button" class="btn btn-primary" style="height: 38px">Search</button>
      </div>
    </div>
    <table class="table">
      <thead>
        <tr>
          <th>Project Name <i class="fa fa-sort" @click="sorting_asc"></i></th>
          <th>Project Location</th>
          <th>Project Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="project in filterSearch">
          <td>{{ project.project_name }}</td>
          <td>{{ project.project_address }}</td>
          <td
            v-if="project.project_status == 'completed'"
            class="text-success status_project"
          >
            {{ project.project_status }}
          </td>
           <td
            v-if="project.project_status == 'upcoming'"
            class="text-info status_project"
          >
            {{ project.project_status }}
          </td>
          <td v-if="project.project_status == 'on-hold'" class="text-info status_project">
            {{ project.project_status }}
          </td>
          <td
            v-if="project.project_status == 'in-progress'"
            class="text-warning status_project"
          >
            {{ project.project_status }}
          </td>
          <td class="remove_bg_td">
            <router-link
              class="action btn"
              :to="{ name: 'edit_project', params: { id: project.id } }"
              >Edit</router-link
            >
             <router-link
              class="action btn ml-2"
              :to="{ name: 'view_project', params: { id: project.id } }"
              >View</router-link
            >
          </td>
        </tr>

        <!-- add more rows as needed -->
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  name: "all_project",
  data() {
    return {
      projects: [],
      sorting: false,
      searchTerm: "",
    };
  },

  methods: {
    sorting_asc() {
      this.sorting = !this.sorting;
      if (this.sorting == true) {
        return this.projects.sort((a, b) => {
          const nameA = a.project_address.toUpperCase();
          const nameB = b.project_address.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0;
        });
      } else {
        return this.projects.sort((a, b) => {
          const nameA = a.project_address.toUpperCase();
          const nameB = b.project_address.toUpperCase();
          if (nameA > nameB) {
            return -1;
          }
          if (nameA < nameB) {
            return 1;
          }
          return 0;
        });
      }
    },
    fetchProjects(url) {
      axios
        .get(url)
        .then((res) => {
          this.projects = res.data;
        })
        .catch((error) => {
        });
    },
  },
  created() {

    this.fetchProjects("/api/project/");
  },
  computed: {
    filterSearch() {
      return this.projects.filter((project) => {
        const search_Term = this.searchTerm.toLowerCase();
        const typeName = project.project_address.toLowerCase();
        return typeName.match(search_Term);
      });
    },
  },
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      // Access the $router property here
      if (!User.hasLoggedIn()) {
        vm.$router.push({ name: "home" });
      } else if (User.getGuard() == "manager") {
        vm.$router.push({ name: "manager_dashboard" });
      } else {
        vm.$router.push({ name: "all_project" });
      }
    });
  },
};
</script>
<style>
.hkf_text {
  color: #4e3089 !important;
}
th {
  font-weight: bold;
  color: #473b5edb;
}
table tr:nth-child(even) {
  background-color: #605ca8 !important;
  color: white;
}
.action {
  color: white;
  background: #5d57c3;
  padding: 5px;
  width: 60px;
}
table tr:nth-child(odd) {
  color: #473b5edb;
  font-weight: bold;
}
.status_project {
  font-weight: bold;
  font-size: 1.2rem;
}
.text-warning {
  color: #35354c !important;
}
.text-info {
  color: #36becc !important;
}
.text-success {
  color: #66a756  !important;
}
.page_to_page {
  margin-bottom: 1rem;
}
table tr:nth-child(even) .remove_bg_td {
  background: white;
}
</style>
