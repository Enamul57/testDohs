<template>
  <div class="row">
    <div class="col-md-12 mx-auto">
      <div class="row">
        <div class="col-md-10 mx-auto">
          <button
            type="button"
            class="btn action_print"
            style="margin-left: 85%"
            @click="printContent"
          >
            Print<i class="fa fa-print pl-2" aria-hidden="true"></i>
          </button>

          <form>
            <div id="print-container">
            <div style='display:flex'>
          <div class="sidebar-brand-icon" style='text-align:left;width:20%;'>
        <img class="logo" src="/img/logo.png" style='width:165%;height:77%;' alt="" />
      </div>
       <div style='padding:5%;width:80%;'>
        <h3 style="text-align: center;">HKF Real Estate LTD</h3>
              <h4 style="text-align: center">
                117/2/8 1st Floor Sopnodanga Residential Area<br>
                Phone: 01400407270  <br>    Email:contact@hkf-re.com <br>
                Website: www.hkf-re.com
              </h4>
      </div>
      </div>
              <h2 class="hkf_title mb-2" style="text-align: center">
                {{ form.clientUnderProject }}
              </h2>
              <p class="hkf_title_print_only" style="color: black; text-align: center">
                {{ this.project_location }}
              </p>
              <h4
                class="hkf_title_print_only"
                style="padding: 0.5rem; color: black; text-align: center"
              >
                ব্যক্তিগত তথ্যাদিঃ
              </h4>

              <div class="row rowPhotoDiv">
                <div class="col-md-8 colPhotoDiv">
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">আইডিঃ</td>
                      <td class="td_label_data">{{ form.client_id }}</td>
                    </label>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">নামঃ</td>
                      <td class="td_label_data">{{ form.name }}</td>
                    </label>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">পিতার নামঃ</td>
                      <td class="td_label_data">{{ form.father_name }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">মাতার নামঃ</td>
                      <td class="td_label_data">{{ form.mother_name }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">স্বামি/স্ত্রীর নামঃ</td>
                      <td class="td_label_data">{{ form.husban_wife_name }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">জন্ম তারিখঃ</td>
                      <td class="td_label_data">{{ form.birth_date }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">ধর্মঃ</td>
                      <td class="td_label_data">{{ form.religion }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">পেশাঃ</td>
                      <td class="td_label_data">{{ form.occupation }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">জাতীয়তাঃ</td>
                      <td class="td_label_data">{{ form.nationality }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <div class="col-md-12">
                      <table
                        style="border: 1px solid black; border-collapse: collapse"
                        class="print_table"
                      >
                        <tr>
                          <th style="border: 1px solid black" class="thikana_print">
                            স্থায়ী ঠিকানা
                          </th>
                          <th style="border: 1px solid black" class="thikana_print">
                            বর্তমান ঠিকানা
                          </th>
                        </tr>
                        <tr>
                          <td
                            style="
                              border: 1px solid black;
                              background: white;
                              color: black;
                            "
                          >
                            <label class="td_label_print"
                              >গ্রাম/রোডঃ {{ form.permanent_location }},</label
                            >
                            <label class="td_label_print"
                              >ডাকঘরঃ {{ form.permanent_post_office }},</label
                            ><label class="td_label_print"
                              >থানা/উপজেলাঃ {{ form.permanent_thana }},</label
                            ><label class="td_label_print"
                              >জেলাঃ {{ form.permanent_district }}</label
                            >
                          </td>
                          <td
                            style="
                              border: 1px solid black;
                              background: white;
                              color: black;
                            "
                          >
                            <label class="td_label_print"
                              >গ্রাম/রোডঃ {{ form.temprorary_location }},</label
                            >
                            <label class="td_label_print"
                              >ডাকঘরঃ {{ form.temprorary_post_office }},</label
                            ><label class="td_label_print"
                              >থানা/উপজেলাঃ {{ form.temprorary_thana }},</label
                            ><label class="td_label_print"
                              >জেলাঃ {{ form.temprorary_district }}</label
                            >
                          </td>
                        </tr>
                      </table>
                    </div>
                  </div>

                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">টি. আই. এনঃ</td>
                      <td class="td_label_data">{{ form.tin }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">মোবাইল নাম্বারঃ</td>
                      <td class="td_label_data">{{ form.phone }}</td></label
                    >
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-6 col-form-label hkf_text_print"
                      ><td class="td_label_info">ইমেল আইডিঃ</td>
                      <td class="td_label_data">{{ form.email }}</td></label
                    >
                  </div>
                </div>
                <div class="col-md-4 colPhotoDiv">
                  <td>
                    <img class="passport_img" :src="'/' + form.profile_photos" alt="" />
                  </td>
                </div>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-6 col-form-label hkf_text_print">
                জাতীয় পরিচয়পত্রের ফটোকপিঃ</label
              >
              <router-link
                :to="{ name: 'nid_client', params: { id: this.Id } }"
                class="btn action_print"
                >Print<i class="fa fa-print pl-2" aria-hidden="true"></i
              ></router-link>
            </div>
            <div class="form-group row">
              <label class="col-sm-6 col-form-label hkf_text_print">
                পাসপোর্টের ফটোকপিঃ</label
              >
              <router-link
                :to="{ name: 'passport_client', params: { id: this.Id } }"
                class="btn action_print"
                >Print<i class="fa fa-print pl-2" aria-hidden="true"></i
              ></router-link>
            </div>

            <div class="form-group row">
              <label class="col-sm-6 col-form-label hkf_text_print"
                >টি. আই. এন ফটোকপিঃ</label
              >
              <router-link
                :to="{ name: 'tin_client', params: { id: this.Id } }"
                class="btn action_print"
                >Print<i class="fa fa-print pl-2" aria-hidden="true"></i
              ></router-link>
            </div>
          </form>
        </div>
      </div>
      <div class="row mt-5" v-if="isAdmin">
        <table class="table">
          <thead>
            <tr>
              <th>Client Name</th>
              <th>Project Name</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="reference in client_projects" :key="reference.id">
              <td>{{ reference.name }}</td>
              <td>{{ reference.clientUnderProject }}</td>
            </tr>

            <!-- add more rows as needed -->
          </tbody>

          <!-- <div class='pagination'>
      <ul v-if="lastPage > 1">
      <li v-for="page in lastPage" :key="page" :class="{ 'active': page === currentPage }">
        <router-link :to="{name:'account_type'}" @click.prevent="setPage(page)">{{ page }}</router-link>
      </li>
    </ul>
    </div> -->
        </table>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "view_client",
  data() {
    return {
      form: {
        name: "",
        father_name: "",
        mother_name: "",
        husban_wife_name: "",
        birth_date: "",
        religion: "",
        occupation: "",
        nationality: "",
        national_id_no: "",
        permanent_location: "",
        permanent_post_office: "",
        permanent_thana: "",
        permanent_district: "",
        temprorary_location: "",
        temprorary_post_office: "",
        temprorary_thana: "",
        temprorary_district: "",
        tin: "",
        phone: "",
        email: "",
        nid_img: "",
        passport_img: "",
        tin_img: "",
        clientUnderProject: "",
        profile_photos: "",
        guard: "",
      },
      project_location: "",
      projects_temp: [],
      Id: "",
      client_projects: [],
      isAdmin: false,
    };
  },
  methods: {
    printContent() {
      const printContents = document.getElementById("print-container").innerHTML;
      const originalContents = document.body.innerHTML;
      const popupWin = window.open("width=800,height=800");
      popupWin.document.open();
      popupWin.document.write(`
        <html>
          <head>
            <style>
              /* Your styles go here */
              *{
                padding:0.25rem;
              }
              .rowPhotoDiv {
                width: 100%;
                display:flex;
              }
              .colPhotoDiv {
                width: 50%;
              }
              .passport_img {
                margin-left:25%;
                width: 120px;
                height: 160px;
                margin-top:-15%;
              }
              .thikana_print{
                border-bottom:1px solid black;
                font-size:1.1em;
              }
             td{
              margin:0.5em;
             }
             .td_label_print {
                padding-right: 0.25rem;;
                width:100%;
              }
              .td_label_data {
                 margin-right: 0.5rem;
                }
                label{
                  padding:.5rem;
                }
                .print_table {

                   width:650px;
                }
                .print_table td {
                  padding: 0.5rem 0rem 0.5rem 1rem;
}
               .hkf_title_print_only{
                 margin-top:-1%;
                  color: black ;
                  text-align: center;
                }
            </style>
          </head>
          <body onload="window.print();window.close();">${printContents}</body>
        </html>
      `);
      popupWin.document.close();
      this.$router.push({ name: "view_client", params: { id: this.$route.params.id } });
    },
  },
  created() {
    let id = this.$route.params.id;
    this.Id = id;

    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "home" });
    } else {
      this.$router.push({ name: "view_client" });
    }

    this.guard = User.getGuard();
    if (this.guard == "admin") {
      this.isAdmin = true;
      axios
        .get("/api/client/" + id)
        .then(({ data }) => {
          this.form = data;
          axios.get("/api/getClientAllProject/" + this.form.name).then((res) => {
            this.client_projects = res.data;
          });
        })
        .catch((err) => {
        });
    }
    axios
      .get("/api/project")
      .then((res) => {
        this.projects_temp = res.data;
        this.projects_temp.forEach((item) => {
          if (item.project_name == this.form.clientUnderProject) {
            this.project_location = item.project_address;
          }
        });
      })
      .catch((err) => {
      });
  },
};
</script>
<style>
.thikana_print {
  color: black !important;
  background: white;
  margin-left: 20%;
  margin-bottom: 2rem;
  text-align: center;
  padding: 0.5rem;
}
.action_print {
  color: white;
  background: #5d57c3;
  padding: 5px;
  width: 90px;
}
.td_label_print {
  padding-right: 1em;
  width: 100%;
}
.td_label_data {
  color: black !important;
  margin-right: 0.5rem;
}
.passport_img {
  width: 150px;
  height: 150px;
}
.print-container {
  margin-top: 1rem;
}
.print_table {
  min-width: 400px;
  width: 590px;
}
.print_table td {
  padding: 0.5rem 0rem 0.5rem 1rem;
}
.hkf_text_print {
  color: black;
}
.td_label_info {
  padding-right: 0.5rem;
}
@media print {
  .rowPhotoDiv {
    width: 100%;
  }
  .colPhotoDiv {
    width: 50%;
  }
  .passport_img {
    width: 120px;
    height: 90px;
  }
  .hkf_title_print_only {
    padding: 0.5rem;
    color: black;
    text-align: center;
  }
}
</style>
