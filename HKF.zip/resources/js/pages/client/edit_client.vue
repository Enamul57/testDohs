<template>
  <div class="row">
    <div class="col-md-12 mx-auto">
      <h2 class="text-center mb-4 hkf_title">Add Client</h2>
      <div class="row">
        <div class="col-md-10 mx-auto">
          <form @submit.prevent="addClient()">
            <div class="form-group row">
              <label class="col-sm-2 col-form-label hkf_text" style="font-size: 1.2em"
                >Select Project</label
              >
              <div class="col-sm-8">
                <select
                  class="form-control"
                  id="status"
                  v-model="form.clientUnderProject"
                  required
                >
                  <option
                    v-for="(project, index) in projects"
                    :value="project.value"
                    :key="index"
                  >
                    {{ project.project_name }}
                  </option>
                </select>
              </div>
            </div>
            <div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.name"
                    required
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">পিতার নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.father_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">মাতার নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.mother_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">স্বামি/স্ত্রীর নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.husban_wife_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জন্ম তারিখ</label>
                <div class="col-sm-8">
                  <input
                    type="date"
                    class="form-control"
                    id="status"
                    v-model="form.birth_date"
                    required
                  />
                  <small class="text text-danger" v-if="errors.birth_date">{{
                    errors.birth_date[0]
                  }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ধর্ম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.religion"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">পেশা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.occupation"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জাতীয়তা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.nationality"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জাতীয় আইডি নং</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.national_id_no"
                    required
                  />
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >স্থায়ী ঠিকানা</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">গ্রাম/রোড</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.permanent_location"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ডাকঘর</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.permanent_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">থানা/উপজেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.permanent_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.permanent_district"
                  />
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >বর্তমান ঠিকানা</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">গ্রাম/রোড</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.temprorary_location"
                    required
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ডাকঘর</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.temprorary_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">থানা/উপজেলা</label>
                <div class="col-sm-6">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.temprorary_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.temprorary_district"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">টি. আই. এন</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.tin"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">মোবাইল নাম্বার</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control"
                    id="status"
                    v-model="form.phone"
                    required
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ইমেল আইডি</label>
                <div class="col-sm-8">
                  <input
                    type="email"
                    class="form-control"
                    id="status"
                    v-model="form.email"
                    required
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">
                  জাতীয় পরিচয়পত্রের ফটোকপি</label
                >
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"
                    id="exampleFormControlFile1"
                    @change="nidFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      v-if="clickOnChooseNid"
                      :src="new_nid_img"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                    <img
                      v-else
                      :src="'/' + form.nid_img"
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">পাসপোর্টের ফটোকপি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"
                    id="exampleFormControlFile1"
                    @change="passportFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      v-if="clickOnChoosePassport"
                      :src="new_passport_img"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                    <img
                      v-else
                      :src="'/' + form.passport_img"
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">টি. আই. এন ফটোকপি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"
                    id="exampleFormControlFile1"
                    @change="tinFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      v-if="clickOnChooseTin"
                      :src="new_tin_img"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                    <img
                      v-else
                      :src="'/' + form.tin_img"
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>

                <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">প্রোফাইল ছবি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"
                    id="exampleFormControlFile1"
                    @change="ProfileFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      v-if="clickOnChooseProfile"
                      :src="new_profile_photos"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                    <img
                      v-else
                      :src="'/' + form.profile_photos"
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>


              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text"></label>
                <div class="col-sm-8">
                  <button type="submit" class="btn btn-primary mb-2 register_client">
                    Update Client
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "edit_client",
  data() {
    return {
      errors: {},
      clickOnChooseTin: false,
      clickOnChooseNid: false,
      clickOnChoosePassport: false,
      clickOnChooseProfile:false,
      form: {
        name: "",
        father_name: "",
        mother_name: "",
        husban_wife_name: "",
        birth_date: "",
        religion: "",
        occupation: "",
        nationality: "",
        national_id_no: "",
        permanent_location: "",
        permanent_post_office: "",
        permanent_thana: "",
        permanent_district: "",
        temprorary_location: "",
        temprorary_post_office: "",
        temprorary_thana: "",
        temprorary_district: "",
        tin: "",
        phone: "",
        email: "",
        nid_img: "",
        passport_img: "",
        tin_img: "",
        profile_photos:"",
        clientUnderProject: "",
        new_nid_img: "",
        new_passport_img: "",
        new_tin_img: "",
        new_profile_photos:"",
        client_id:"",
        manager_username:"",
        guard:"",
      },
      new_nid_img: "",
      new_passport_img: "",
      new_tin_img: "",
      new_profile_photos:"",
      projects: [],
    };
  },
  methods: {
    nidFileSelected(event) {
      this.clickOnChooseNid = true;

      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.new_nid_img = event.target.result;
        this.new_nid_img = this.form.new_nid_img;
      };
      reader.readAsDataURL(file);
    },
    passportFileSelected(event) {
      this.clickOnChoosePassport = true;
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.new_passport_img = event.target.result;
        this.new_passport_img = this.form.new_passport_img;
      };
      reader.readAsDataURL(file);
    },
    tinFileSelected(event) {
      this.clickOnChooseTin = true;
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.new_tin_img = event.target.result;
        this.new_tin_img = this.form.new_tin_img;
      };
      reader.readAsDataURL(file);
    },
     ProfileFileSelected(event) {
      this.clickOnChooseProfile = true;
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.new_profile_photos = event.target.result;
        this.new_profile_photos = this.form.new_profile_photos;
      };
      reader.readAsDataURL(file);
    },
    addClient() {
      if(this.form.client_id == ""){
         const alphabet = "abcdefghijklmnopqrstuvwxyz";
         let randomString = "";
          for (let i = 0; i <3; i++) {
          const randomIndex = Math.floor(Math.random() * alphabet.length);
         const randomLetter = alphabet.charAt(randomIndex);
           randomString += randomLetter;
        }
        const uniqueId = randomString + "-" + Math.floor(Math.random() * 10000);
        this.form.client_id = uniqueId;

         let id = this.$route.params.id;
         axios
        .patch("/api/client/" + id, this.form)
        .then((res) => {
          this.$router.push({ name: "all_client" });
        })
        .catch((err) => {
        });
      }else{
         let id = this.$route.params.id;
      axios
        .patch("/api/client/" + id, this.form)
        .then((res) => {
          this.$router.push({ name: "all_client" });
        })
        .catch((err) => {
        });
      }


    },
  },
  computed: {},
  created() {
    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "home" });
    } else {
      this.$router.push({ name: "edit_client" });
    }
    let id = this.$route.params.id;
    axios
      .get("/api/client/" + id)
      .then((res) => {
        this.form = res.data;
      })
      .catch((err) => {
      });
    //admin  & manager
    this.guard = User.getGuard();
    if(this.guard =='admin'){

         axios
      .get("/api/project")
      .then(({ data }) => {
        this.projects = data.map((item) => ({
          project_name: item.project_name,
          value: item.project_name,
          id: item.id,
        }));
      })
      .catch((err) => {
        this.errors = err.response.data;
      });
    }else if(this.guard =='manager'){
        this.manager_username = User.getUserName();
        axios.get('/api/getManagerProject/'+this.manager_username).then((res)=>{
            this.projects = res.data.map((item) => ({
          project_name: item.project,
          value: item.project,
          id: item.id,
        }));
        }).catch((err)=>{
        });
    }
  },
};
</script>
<style>
input {
  border: 1px solid #adaadd !important;
}
.thikana {
  color: white !important;
  background: #5a629b;
  margin-left: 12%;
  margin-bottom: 2rem;
  text-align: center;
}
.register_client {
  margin-left: 70%;
}
</style>
