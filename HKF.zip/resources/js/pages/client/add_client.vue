<template>
  <div class="row">
    <div class="col-md-12 mx-auto">
      <h2 class="text-center mb-4 hkf_title">Add Client
</h2>
<button type="button" class='action btn text-right' style='width:80px; margin-left:80%;margin-top:1rem;margin-bottom:1rem;' @click='translate'>Translate</button>
      <div class="row">
        <div class="col-md-10 mx-auto">
          <form @submit.prevent="addClient()">
            <div class="form-group row">
              <label class="col-sm-2 col-form-label hkf_text" style="font-size: 1.2em"
                >Select Project</label
              >
              <div class="col-sm-8">
                <select
                  class="form-control status"

                  v-model="form.clientUnderProject"
                  @change="checkOption"
                >
                  <option
                    v-for="(project, index) in projects"
                    :value="project.value"
                    :key="index"
                  >
                    {{ project.project_name }}
                  </option>
                </select>
                <small class="text text-danger" v-if="errors.clientUnderProject">{{
                  errors.clientUnderProject[0]
                }}</small>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label hkf_text" style="font-size: 1.2em"
                >Select Client Status</label
              >
              <div class="col-sm-8">
                <select
                  class="form-control status"

                  v-model="client.statuses"
                  @change="checkClient"
                >
                  <option v-for="(client, index) in clientStatus"  :key="index" :value="client.status">
                    {{ client.status }}
                  </option>
                </select>
              </div>
            </div>
            <div class="form-group row" v-if="client_profile">
              <label class="col-sm-2 col-form-label hkf_text" style="font-size: 1.2em"
                >Select Client
              </label>
              <div class="col-sm-8">
                <select
                  class="form-control status"

                  v-model="client.name"
                  @change="chooseClient"
                >
                  <option v-for="(client, index) in clients" :key="index">
                    {{ client.name }}
                  </option>
                </select>
              </div>
            </div>
            <div v-show="client_status && bangla" >
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control "

                    v-model="form.name"
                  />
                  <small class="text text-danger" v-if="errors.name">{{
                  errors.name[0]
                }}</small>
                </div>

              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">পিতার নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.father_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">মাতার নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.mother_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">স্বামি/স্ত্রীর নাম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.husban_wife_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জন্ম তারিখ</label>
                <div class="col-sm-8">
                  <input
                    type="date"
                    class="form-control status"

                    v-model="form.birth_date"
                  />
                  <small class="text text-danger" v-if="errors.birth_date">{{
                    errors.birth_date[0]
                  }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ধর্ম</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.religion"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">পেশা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.occupation"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জাতীয়তা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.nationality"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জাতীয় আইডি নং</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.national_id_no"
                  />
                  <small class="text text-danger" v-if="errors.national_id_no">{{
                  errors.national_id_no[0]
                }}</small>
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >স্থায়ী ঠিকানা</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">গ্রাম/রোড</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_location"
                  />

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ডাকঘর</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">থানা/উপজেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_district"
                  />
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >বর্তমান ঠিকানা</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">গ্রাম/রোড</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_location"
                  />
                  <small class="text text-danger" v-if="errors.temprorary_location">{{
                  errors.temprorary_location[0]
                }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ডাকঘর</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">থানা/উপজেলা</label>
                <div class="col-sm-6">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">জেলা</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_district"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">টি. আই. এন</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.tin"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">মোবাইল নাম্বার</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.phone"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">ইমেল আইডি</label>
                <div class="col-sm-8">
                  <input
                    type="email"
                    class="form-control status"

                    v-model="form.email"
                  />
                  <small class="text text-danger" v-if="errors.email">{{
                  errors.email[0]
                }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">
                  জাতীয় পরিচয়পত্রের ফটোকপি</label
                >
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="nidFileSelected"
                  />
                  <small class="text text-danger" v-if="errors.nid_img">{{
                  errors.nid_img[0]
                }}</small>
                </div>
                <div class="col-md-4">
                  <td>
                    <img :src="form.nid_img" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">পাসপোর্টের ফটোকপি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="passportFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      :src="form.passport_img"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">টি. আই. এন ফটোকপি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="tinFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img :src="form.tin_img" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>
               <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">প্রোফাইল ছবি</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="profileFileSelected"
                  />
                </div>

                <div class="col-md-4">
                  <td>
                    <img :src="form.profile_photos" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>
            </div>
             <div v-show="client_status && english" >
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Name</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.name"
                  />
                  <small class="text text-danger" v-if="errors.name">{{
                  errors.name[0]
                }}</small>
                </div>

              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Father's Name</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.father_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Mother's Name</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.mother_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Husband/Wife Name</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.husban_wife_name"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Birth Date</label>
                <div class="col-sm-8">
                  <input
                    type="date"
                    class="form-control status"

                    v-model="form.birth_date"
                  />
                  <small class="text text-danger" v-if="errors.birth_date">{{
                    errors.birth_date[0]
                  }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Religion</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.religion"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Occupation</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.occupation"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Nationality</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.nationality"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">National ID No</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.national_id_no"
                  />
                  <small class="text text-danger" v-if="errors.national_id_no">{{
                  errors.national_id_no[0]
                }}</small>
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >Permanent Address</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Village/Road</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_location"
                  />

                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Post Office</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Police Station/Upazila</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">District</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.permanent_district"
                  />
                </div>
              </div>

              <div class="row">
                <label class="col-sm-8 col-form-label thikana" style="color: black"
                  >Present Address</label
                >
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Village/Road</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_location"
                  />
                  <small class="text text-danger" v-if="errors.temprorary_location">{{
                  errors.temprorary_location[0]
                }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Post Office</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_post_office"
                  />
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Police Station/Upazila</label>
                <div class="col-sm-6">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_thana"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">District</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.temprorary_district"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">T. I. N.</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.tin"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Mobile Number</label>
                <div class="col-sm-8">
                  <input
                    type="text"
                    class="form-control status"

                    v-model="form.phone"
                  />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2 col-form-label hkf_text">Email</label>
                <div class="col-sm-8">
                  <input
                    type="email"
                    class="form-control status"

                    v-model="form.email"
                  />
                  <small class="text text-danger" v-if="errors.email">{{
                  errors.email[0]
                }}</small>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">
                  NID Photocopy</label
                >
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="nidFileSelected"
                  />
                  <small class="text text-danger" v-if="errors.nid_img">{{
                  errors.nid_img[0]
                }}</small>
                </div>
                <div class="col-md-4">
                  <td>
                    <img :src="form.nid_img" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">Passport Photocopy</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="passportFileSelected"
                  />
                </div>
                <div class="col-md-4">
                  <td>
                    <img
                      :src="form.passport_img"
                      alt=""
                      style="width: 50%; height: auto"
                    />
                  </td>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">T. I. N. Photocopy</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="tinFileSelected"
                  />
                </div>

                <div class="col-md-4">
                  <td>
                    <img :src="form.tin_img" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>
               <div class="form-group row">
                <label class="col-sm-3 col-form-label hkf_text">Profile Photo</label>
                <div class="col-sm-3">
                  <input
                    type="file"
                    class="form-control-file"

                    @change="profileFileSelected"
                  />
                </div>

                <div class="col-md-4">
                  <td>
                    <img :src="form.profile_photos" alt="" style="width: 50%; height: auto" />
                  </td>
                </div>
              </div>

            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label hkf_text"></label>
              <div class="col-sm-8">
                <button type="submit" class="btn btn-primary mb-2 register_client">
                  Register Client
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "add_client",
  data() {
    return {
      errors: {},
      clientStatus: [],
      client: {
        statuses: "",
        name: "",
      },
      bangla:true,
      english:false,
      form: {
        name: "",
        father_name: "",
        mother_name: "",
        husban_wife_name: "",
        birth_date: "",
        religion: "",
        occupation: "",
        nationality: "",
        national_id_no: "",
        permanent_location: "",
        permanent_post_office: "",
        permanent_thana: "",
        permanent_district: "",
        temprorary_location: "",
        temprorary_post_office: "",
        temprorary_thana: "",
        temprorary_district: "",
        tin: "",
        phone: "",
        email: "",
        nid_img: "",
        passport_img: "",
        tin_img: "",
        clientUnderProject: "",
        client_id:"",
        profile_photos:"",
      },
      clientStatus:[
        {status:'Exist'},
        {status:'New'},
      ],
      newform: {
        name: "",
        father_name: "",
        mother_name: "",
        husban_wife_name: "",
        birth_date: "",
        religion: "",
        occupation: "",
        nationality: "",
        national_id_no: "",
        permanent_location: "",
        permanent_post_office: "",
        permanent_thana: "",
        permanent_district: "",
        temprorary_location: "",
        temprorary_post_office: "",
        temprorary_thana: "",
        temprorary_district: "",
        tin: "",
        phone: "",
        email: "",
        nid_img: "",
        passport_img: "",
        tin_img: "",
        clientUnderProject: "",
        profile_photos:"",
         client_id: "",
      },
      guard:"",
      checkData: false,
      projects: [],
      client_status: false,
      clients: [],
      client_profile: false,
      exist_button: false,
      existing: false,
      newentry: false,
      client_id:'',
      manager_username:"",
    };
  },
  methods: {
    translate(){
        if(this.bangla==true){
          this.bangla=false;
          this.english = true;
        }else if(this.english==true){
          this.english=false;
          this.bangla=true;
        }
    },
    nidFileSelected(event) {
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.nid_img = event.target.result;
      };
      reader.readAsDataURL(file);
    },
    passportFileSelected(event) {
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.passport_img = event.target.result;
      };
      reader.readAsDataURL(file);
    },
    tinFileSelected(event) {
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.tin_img = event.target.result;
      };
      reader.readAsDataURL(file);
    },
    profileFileSelected(){
      let file = event.target.files[0];
      let reader = new FileReader();
      reader.onload = (event) => {
        this.form.profile_photos = event.target.result;
      };
      reader.readAsDataURL(file);
    },
    addClient() {
      if (this.newentry) {
        const alphabet = "abcdefghijklmnopqrstuvwxyz";
         let randomString = "";
          for (let i = 0; i <3; i++) {
          const randomIndex = Math.floor(Math.random() * alphabet.length);
         const randomLetter = alphabet.charAt(randomIndex);
           randomString += randomLetter;
        }
      const uniqueId = randomString + "-" + Math.floor(Math.random() * 10000);
      this.form.client_id= uniqueId;
        axios
          .post("/api/client", this.form)
          .then((res) => {
             this.$router.push({ name: "all_client" });
          })
          .catch((err) => {
            this.errors = JSON.parse(err.response.data);
          });
      } else if (this.existing) {
        let id = this.client_id;

        let newProject = this.form.clientUnderProject;
        axios
          .get("/api/client/" + id)
          .then((res) => {
            this.form = res.data;
            if (this.form) {
              this.newform.name = this.form.name;
              this.newform.father_name = this.form.father_name;
              this.newform.mother_name = this.form.mother_name;
              this.newform.husban_wife_name = this.form.husban_wife_name;
              this.newform.birth_date = this.form.birth_date;
              this.newform.religion = this.form.religion;
              this.newform.occupation = this.form.occupation;
              this.newform.nationality = this.form.nationality;
              this.newform.national_id_no = this.form.national_id_no;
              this.newform.permanent_location = this.form.permanent_location;
              this.newform.permanent_post_office = this.form.permanent_post_office;
              this.newform.permanent_thana = this.form.permanent_thana;
              this.newform.permanent_district = this.form.permanent_district;
              this.newform.temprorary_location = this.form.temprorary_location;
              this.newform.temprorary_post_office = this.form.temprorary_post_office;
              this.newform.temprorary_thana = this.form.temprorary_thana;
              this.newform.temprorary_district = this.form.temprorary_district;
              this.newform.tin = this.form.tin;
              this.newform.phone = this.form.phone;
              this.newform.email = this.form.email;
              this.newform.nid_img = this.form.nid_img;
              this.newform.passport_img = this.form.passport_img;
              this.newform.tin_img = this.form.tin_img;
              this.newform.client_id=this.form.client_id;
              this.newform.clientUnderProject = newProject;
              axios
                .post("/api/client/existing_entry/", this.newform)
                .then((res) => {
                  this.$router.push({ name: "all_client" });
                })
                .catch((err) => console.log(err.response));
            }
          })
          .catch((err) => {
          });
      }
    },
  },
  computed: {

    checkClient() {
      if (this.client.statuses == "Exist") {
        this.client_status = false;
        this.existing = true;
        this.newentry = false;
        this.client_profile = true;
      } else {
        this.client_status = true;
        this.client_profile = false;
        this.existing = false;
        this.newentry = true;
      }
    },
    checkOption() {
      if (this.form.clientUnderProject != "") {
        this.checkData = true;
      } else {
        this.checkData = false;
      }
    },
    chooseClient() {
      this.clients.forEach((item) => {
        if (item.name == this.client.name) {
          this.client_id = item.id;

        }
      });


    },
  },
  created() {
    if (!User.hasLoggedIn()) {
      this.$router.push({ name: "home" });
    } else {
      this.$router.push({ name: "add_client" });
    }

    //admin  & manager
    this.guard = User.getGuard();
    if(this.guard =='admin'){

         axios
      .get("/api/project")
      .then(({ data }) => {
        this.projects = data.map((item) => ({
          project_name: item.project_name,
          value: item.project_name,
          id: item.id,
        }));
      })
      .catch((err) => {
        this.errors = err.response.data;
      });
    }else if(this.guard =='manager'){
        this.manager_username = User.getUserName();
        axios.get('/api/getManagerProject/'+this.manager_username).then((res)=>{
            this.projects = res.data.map((item) => ({
          project_name: item.project,
          value: item.project,
          id: item.id,
        }));
        }).catch((err)=>{
        });
    }


    axios
      .get("/api/client")
      .then((res) => {
        this.clients = res.data;
      })
      .catch((err) => {
      });
  },
};
</script>
<style>
input {
  border: 1px solid #adaadd !important;
}
.thikana {
  color: white !important;
  background: #5a629b;
  margin-left: 12%;
  margin-bottom: 2rem;
  text-align: center;
}
.register_client {
  margin-left: 70%;
}
</style>
