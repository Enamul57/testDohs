<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

use App\Models\Client;
use Illuminate\Support\Facades\Validator;
use Image;
class ClientInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $clients = Client::all();

        return response()->json($clients);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make($request->all(), [
            'clientUnderProject'=> 'required|min:2',
            'name'=>'required',
            'birth_date'=>'date|before:today',
            'national_id_no'=>'required',
            'temprorary_location' =>'required',
            'email' =>'required',
            'nid_img' =>'required',

        ],
    [
        'birth_date.before' => 'The birthdate cannot be today\'s date.',
        'clientUnderProject.required' => 'Please select project',
        'name.required' => 'The name is required',
        'national_id_no.required' => 'National ID is requried',
        'temprorary_location.required' => 'Location is requried',
        'email.required' => 'The email is requried',
        'nid_img.required' => 'NID copy is required',
    ]);
       if($validator->fails()){
        return response()->json($validator->errors()->toJson(),400);
       }
            //nid image
            $client = new Client();
            $check1= DB::table('clients')->where('national_id_no',$request->national_id_no)->first();
            if(!$check1){
                $check= DB::table('clients')->where('name',$request->name)->where('clientUnderProject',$request->clientUnderProject)->first();
                if(!$check){

            $image = $request->nid_img;// abc/jpg;dfdsfsa
            $index_position = strpos($image,';');
            $substr = substr($image,0,$index_position);
            $ext = explode('/',$substr)[1];
            $uniqueName = hexdec(uniqid()).".".$ext;
            $imgFile = Image::make($image);
            $upload_path = 'AdminPanel/client_image/';
            $imageUrl = $upload_path.$uniqueName;
            $imgFile->save($imageUrl);

             //passport image
             $image1 = $request->passport_img;// abc/jpg;dfdsfsa
             if($image1){
                $index_position1 = strpos($image1,';');
                $substr1 = substr($image1,0,$index_position1);
                $ext1 = explode('/',$substr1)[1];
                $uniqueName1 = hexdec(uniqid()).".".$ext1;
                $imgFile1 = Image::make($image1);
                $upload_path1 = 'AdminPanel/client_image/';
                $imageUrl1 = $upload_path1.$uniqueName1;
                $imgFile1->save($imageUrl1);
                $client->passport_img = $imageUrl1;

             }else{
                $client->passport_img = "";

             }



            //tin image

             $image2 = $request->tin_img;// abc/jpg;dfdsfsa
             if($image2){
                $index_position2 = strpos($image2,';');
                $substr2 = substr($image2,0,$index_position2);
                $ext2 = explode('/',$substr2)[1];
                $uniqueName2 = hexdec(uniqid()).".".$ext2;
                $imgFile2 = Image::make($image2);
                $upload_path2 = 'AdminPanel/client_image/';
                $imageUrl2 = $upload_path2.$uniqueName2;
                $imgFile2->save($imageUrl2);
                $client->tin_img = $imageUrl2;
             }else{
                $client->tin_img = "";
             }

             $image3 = $request->profile_photos;// abc/jpg;dfdsfsa
             if($image3){
                $index_position3 = strpos($image3,';');
                $substr3 = substr($image3,0,$index_position3);
                $ext3 = explode('/',$substr3)[1];
                $uniqueName3 = hexdec(uniqid()).".".$ext3;
                $imgFile3 = Image::make($image3);
                $upload_path3 = 'AdminPanel/client_image/';
                $imageUrl3 = $upload_path3.$uniqueName3;
                $imgFile3->save($imageUrl3);
                $client->profile_photos = $imageUrl3;
             }else{
                $client->profile_photos = "";
             }


            $client->name = $request->name;
            $client->father_name = $request->father_name;
            $client->mother_name = $request->mother_name;
            $client->husban_wife_name = $request->husban_wife_name;
            $client->birth_date = $request->birth_date;
            $client->religion = $request->religion;
            $client->occupation = $request->occupation;
            $client->nationality = $request->nationality;
            $client->national_id_no = $request->national_id_no;
            $client->permanent_location = $request->permanent_location;
            $client->permanent_post_office = $request->permanent_post_office;
            $client->permanent_thana = $request->permanent_thana;
            $client->permanent_district = $request->permanent_district;
            $client->temprorary_location = $request->temprorary_location;
            $client->temprorary_post_office = $request->temprorary_post_office;
            $client->temprorary_thana = $request->temprorary_thana;
            $client->temprorary_district = $request->temprorary_district;
            $client->tin = $request->tin;
            $client->phone = $request->phone;
            $client->email = $request->email;
            $client->nid_img = $imageUrl;
            $client->client_id = $request->client_id;
            $client->clientUnderProject = $request->clientUnderProject;



            $client->save();
            return response()->json($client);
                }
            }



    }
    public function storeExist(Request $request){
            $client = new Client();
            $client->name = $request->name;
            $client->father_name = $request->father_name;
            $client->mother_name = $request->mother_name;
            $client->husban_wife_name = $request->husban_wife_name;
            $client->birth_date = $request->birth_date;
            $client->religion = $request->religion;
            $client->occupation = $request->occupation;
            $client->nationality = $request->nationality;
            $client->national_id_no = $request->national_id_no;
            $client->permanent_location = $request->permanent_location;
            $client->permanent_post_office = $request->permanent_post_office;
            $client->permanent_thana = $request->permanent_thana;
            $client->permanent_district = $request->permanent_district;
            $client->temprorary_location = $request->temprorary_location;
            $client->temprorary_post_office = $request->temprorary_post_office;
            $client->temprorary_thana = $request->temprorary_thana;
            $client->temprorary_district = $request->temprorary_district;
            $client->tin = $request->tin;
            $client->phone = $request->phone;
            $client->email = $request->email;
            $client->nid_img = $request->nid_img;
            $client->tin_img = $request->tin_img;
            $client->passport_img = $request->passport_img;
            $client->clientUnderProject = $request->clientUnderProject;
            $client->profile_photos = $request->profile_photos;
            $client->client_id = $request->client_id;


            $client->save();
    }
    public function getProjectFromClientInfo($client_nid){
        $nid = $client_nid;

        $getProject = DB::table('clients')->select('clients.clientUnderProject')->where('national_id_no',$nid)->get();
        return response()->json($getProject);
    }

    public function getClientInfo($client_id){
        $id = $client_id;
        $getClient = DB::table('clients')->select('clients.*')->where('client_id',$id)->first();
        return response()->json($getClient);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $client = Client::find($id);
        return response()->json($client);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $client = array();
        $client['name']= $request->name;
        $client['father_name']= $request->father_name;
        $client['mother_name']= $request->mother_name;
        $client['husban_wife_name']= $request->husban_wife_name;
        $client['religion']= $request->religion;
        $client['birth_date']= $request->birth_date;
        $client['occupation']= $request->occupation;
        $client['email']= $request->email;
        $client['phone']= $request->phone;
        $client['tin']= $request->tin;
        $client['nationality']= $request->nationality;
        $client['national_id_no']= $request->national_id_no;
        $client['permanent_location']= $request->permanent_location;
        $client['permanent_post_office']= $request->permanent_post_office;
        $client['permanent_thana']= $request->permanent_thana;
        $client['permanent_district']= $request->permanent_district;
        $client['temprorary_location']= $request->temprorary_location;
        $client['temprorary_post_office']= $request->temprorary_post_office;
        $client['temprorary_thana']= $request->temprorary_thana;
        $client['temprorary_district']= $request->temprorary_district;
        $client['clientUnderProject']= $request->clientUnderProject;
        $client['client_id']= $request->client_id;

        $imgNid= $request->new_nid_img;
        if($imgNid){
            $index_position = strpos($imgNid,';');
            $substr = substr($imgNid,0,$index_position);
            $ext = explode('/',$substr)[1];
            $uniqueName = hexdec(uniqid()).".".$ext;
            $img = Image::make($imgNid);
            $path = 'AdminPanel/client_image/';
            $imgUrl = $path.$uniqueName;
            $imgSave = $img->save($imgUrl);
                if($imgSave){
                    $client['nid_img'] = $imgUrl;
                    $database_photo = DB::table('clients')->where('id',$id)->first();
                   if($database_photo->nid_img){
                    $old_photo = $database_photo->nid_img;
                    unlink($old_photo);
                   }


                }
        }else{
            $old_photo = $request->nid_img;
            $product['nid_img'] = $old_photo;

        }

        //passport
        $imgPassport= $request->new_passport_img;
        if($imgPassport){
            $index_position = strpos($imgPassport,';');
            $substr = substr($imgPassport,0,$index_position);
            $ext = explode('/',$substr)[1];
            $uniqueName = hexdec(uniqid()).".".$ext;
            $img = Image::make($imgPassport);
            $path = 'AdminPanel/client_image/';
            $imgUrl = $path.$uniqueName;
            $imgSave = $img->save($imgUrl);
                if($imgSave){
                    $client['passport_img'] = $imgUrl;
                    $database_photo = DB::table('clients')->where('id',$id)->first();
                   if($database_photo->passport_img){
                    $old_photo = $database_photo->passport_img;
                    unlink($old_photo);
                   }


                }
        }else{
            $old_photo = $request->passport_img;
            $product['passport_img'] = $old_photo;

        }

        //tin
        $imgTin= $request->new_tin_img;
        if($imgTin){
            $index_position = strpos($imgTin,';');
            $substr = substr($imgTin,0,$index_position);
            $ext = explode('/',$substr)[1];
            $uniqueName = hexdec(uniqid()).".".$ext;
            $img = Image::make($imgTin);
            $path = 'AdminPanel/client_image/';
            $imgUrl = $path.$uniqueName;
            $imgSave = $img->save($imgUrl);
                if($imgSave){
                    $client['tin_img'] = $imgUrl;
                    $database_photo = DB::table('clients')->where('id',$id)->first();
                   if($database_photo->tin_img){
                    $old_photo = $database_photo->tin_img;
                    unlink($old_photo);
                   }


                }
        }else{
            $old_photo = $request->tin_img;
            $product['tin_img'] = $old_photo;

        }
        //profile photo
        $imgProfile= $request->new_profile_photos;
        if($imgProfile){
            $index_position = strpos($imgProfile,';');
            $substr = substr($imgProfile,0,$index_position);
            $ext = explode('/',$substr)[1];
            $uniqueName = hexdec(uniqid()).".".$ext;
            $img = Image::make($imgProfile);
            $path = 'AdminPanel/client_image/';
            $imgUrl = $path.$uniqueName;
            $imgSave = $img->save($imgUrl);
                if($imgSave){
                    $client['profile_photos'] = $imgUrl;
                    $database_photo = DB::table('clients')->where('id',$id)->first();
                   if($database_photo->profile_photos){
                    $old_photo = $database_photo->profile_photos;
                    unlink($old_photo);
                   }


                }
        }else{
            $old_photo = $request->profile_photos;
            $product['profile_photos'] = $old_photo;

        }



        $user =DB::table('clients')->where('id',$id)->update($client);
        return response()->json($user);
        }





    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
