<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\payable_journal;
use App\Models\Inventory;
use App\Models\Admin;
use App\Models\Manager;
use App\Models\ReceiptPayableJournal;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class GetApNameController extends Controller
{
    //

    public function getReference($voucher){
        $index = DB::table('references')->where('voucher_no',$voucher)->first();
        return response()->json($index);
    }
    public function getApName(Request $request)
    {
        $index = DB::table('payment_vouchers')->where('payment_id', $request->payment_id)->first();

        return response()->json($index);
    }

    public function getApLedger()
    {
        $index = DB::table('pay_payables')->join('payable_journals', 'pay_payables.payment_id', '=', 'payable_journals.payment_id')->select('pay_payables.*')->get();
        return response()->json($index);
    }
    public function getApledgerRcpt()
    {
        $index = DB::table('pay_receivables')->join('receipt_payable_journals', 'pay_receivables.receipt_id', '=', 'receipt_payable_journals.receipt_id')->select('pay_receivables.*')->get();
        return response()->json($index);
    }

    public function getPayableData($payment_id)
    {
        $getData = DB::table('pay_payables')->join('payable_journals', 'pay_payables.payment_id', '=', 'payable_journals.payment_id')->select('pay_payables.*', 'payable_journals.payee_name')->where('pay_payables.payment_id', $payment_id)->latest('created_at')->first();

        return response()->json($getData);
    }
    public function checkDueClear($payment_id)
    {
        $getData = DB::table('pay_payables')->where('payment_id', $payment_id)->first();
        return response()->json($getData);
    }

    public function checkDueClearReceipt($receipt_id){
        $getData = DB::table('pay_receivables')->where('receipt_id', $receipt_id)->first();
        return response()->json($getData);
    }

    public function getPayableID($payment_id)
    {

        $index = DB::table('pay_payables')->where('payment_id', $payment_id)->first();
        if ($index) {
            return response()->json(['id' => $index]);
        } else {
            return response()->json(['id' => 'empty']);
        }

    }

    public function getPaymentVoucher($payment_id)
    {
        $index = DB::table('payment_vouchers')->where('payment_id', $payment_id)->first();
        return response()->json($index);
    }
    public function checkReturns($payment_id)
    {
        $index = DB::table('purchase_returns')->where('payment_id', $payment_id)->first();
        return response()->json($index);
    }

    public function getName($payment_id)
    {
        $index = DB::table('payment_vouchers')->where('payment_id', $payment_id)->first();
        return response()->json($index);
    }

    public function checkPropertyId(Request $request)
    {
        $project = $request->property_project;
        $building_name = $request->building_name;
        $notEmpty = Inventory::all();
        if (count($notEmpty) > 0) {
            if ($request->property_type == "Building") {
                $checkProject = DB::table('inventories')->where('property_project', $project)->first();
                if ($checkProject) {
                    $index = DB::table('inventories')->where('building_name', $building_name)->first();
                    return response()->json($index);
                }

            }
        }
    }

    public function filterProductType(Request $request)
    {
        if (strtolower($request->property_type) == 'land') {
            $index = DB::table('inventories')->whereRaw('lower(property_type) = ?', 'land')->where('property_status', 'Available')->get();
            return response()->json($index);

        } else if ($request->selectedProject != "" || strtolower($request->property_type) != 'land') {
            $index = DB::table('inventories')->whereRaw('lower(property_type) != ?', 'land')->where('property_status', 'Available')->where('property_project', $request->selectedProject)->get();

            return response()->json($index);
        }

    }

    public function getBuildingName(Request $request)
    {
        $index = DB::table('inventories')->select('inventories.building_name')->where('property_status', 'Available')->where('property_type', 'Building')->where('property_project', $request->selectedProject)->distinct()->get();
        return response()->json($index);
    }

    public function getPropertyLabel(Request $request)
    {
        $index = DB::table('inventories')->select('inventories.*')->where('property_project', $request->selectedProject)->where('property_status', 'Available')->where('building_name', $request->building_name)->where('sub_property_type', $request->selected_label)->get();
        return response()->json($index);
    }

    public function getPropertyId(Request $request)
    {
        return response()->json($request);
    }

    public function getProductTotal(Request $request)
    {
        $getIdByBuildingName = DB::table('inventories')->where('building_name', $request->building_name)->where('property_project', $request->selectedProject)->first();
        $data = array();
        $data['property_id'] = $getIdByBuildingName->property_id;
        $totalAmount = 0;
        $getDataByBuildingName = DB::table('inventories')->where('property_id', $getIdByBuildingName->property_id)->where('property_status', 'Available')->get();
        if ($getDataByBuildingName) {
            foreach ($getDataByBuildingName as $gdb) {
                $totalAmount += $gdb->property_amount;
            }
        }
        $data['product_amount'] = $totalAmount;
        return response()->json($data);
    }

    public function getFirstInstall($payment_id)
    {
        $index1 = DB::table('pay_payables')->where('payment_id', $payment_id)->first();
        $index2 = DB::table('payment_vouchers')->where('payment_id', $payment_id)->first();
        $data = [
            'total_received' => $index2->receive_amount,
            'due_clear' => $index1->receive_amount,
        ];
        return response()->json($data);
    }
    public function getFirstInstallReceipt($receipt_id){
        $index1 = DB::table('pay_receivables')->where('receipt_id', $receipt_id)->first();
        $index2 = DB::table('receipt_vouchers')->where('receipt_id', $receipt_id)->first();
        $data = [
            'total_received' => $index2->total_amount,
            'due_clear' => $index1->receive_amount,
        ];
        return response()->json($data);
    }

    public function getReceiptName($receipt_id)
    {
        $index = DB::table('receipt_vouchers')->where('receipt_id', $receipt_id)->first();
        return response()->json($index);

    }

    public function getPurchaseAmount()
    {
        $index = DB::table('payment_vouchers')->select('payment_vouchers.*')->get();
        $totalBalance = 0;
        if ($index) {
            foreach ($index as $ind) {
                $totalBalance += intval($ind->receive_amount);
            }
        }
        return response()->json($totalBalance);
    }

    public function getSalesAmount()
    {
        $index = DB::table('receipt_vouchers')->select('receipt_vouchers.*')->get();
        $totalBalance = 0;
        if ($index) {
            foreach ($index as $ind) {
                $totalBalance += intval($ind->total_amount);
            }
        }
        return response()->json($totalBalance);

    }

    public function getPaymentDue()
    {
        $index = DB::table('payment_vouchers')->select('payment_vouchers.*')->get();
        $totalBalance = 0;
        if ($index) {
            foreach ($index as $ind) {
                $totalBalance += intval($ind->payment_due);
            }
        }
        return response()->json($totalBalance);
    }

    public function getReceiptDue()
    {
        $index = DB::table('receipt_vouchers')->select('receipt_vouchers.*')->get();
        $totalBalance = 0;
        if ($index) {
            foreach ($index as $ind) {
                $totalBalance += intval($ind->due);
            }
        }
        return response()->json($totalBalance);

    }

    public function pieChart()
    {
        $indexArray = [];
        $index = DB::table('receipt_vouchers')->select('receipt_vouchers.*')->get();
        if ($index) {
            foreach ($index as $ind) {
                $indexArray[] = [

                    $ind->selectedProject,
                    $ind->total_amount,
                ];
            }
        }
        return response()->json($indexArray);
    }

    public function areaChart()
    {
        $indexArray = [];
        $index = DB::table('receipt_vouchers')->select('receipt_vouchers.*')->get();
        if ($index) {
            foreach ($index as $ind) {
                $indexArray[] = [

                    $ind->basic_date,
                   ( $ind->total_amount),
                ];
            }
        }
        return response()->json($indexArray);
    }

    public function fetchStock($product_name){
        $index = DB::table('stock_journals')->where('product_name',$product_name)->first();
        return response()->json($index);
    }

    public function getUnit($product_name){
        $index = DB::table('units')->where('item_name',$product_name)->first();
        return response()->json($index);
    }

    public function getStage($id){
        $index  = DB::table('project_stages')->where('id',$id)->first();
        return response()->json($index);
    }
    public function reference_clients(Request $request){
        $index = DB::table('references')->where('reference_id',$request->reference_id)->get();
        return response()->json($index);
    }

    public function project_lists (){
        $index= DB::table('project_members')->select('project_members.project',DB::raw('MIN(id) as id'))->groupBy('project')->get();
        return response()->json($index);
    }
    public function fetchProjectFromLists($id){
        $getProjectName = DB::table('project_members')->where('id',$id)->select('project_members.project')->first();
        return response()->json($getProjectName);
    }
    public function fetchMemberByProject($project){
        $index = DB::table('project_members')->where('project',$project)->get();
        return response()->json($index);
    }

    public function getAllManager(){
        $index = DB::table('managers')->get();
        return response()->json($index);
    }

    public function managerUsername($username){
            $index = DB::table('managers')->where('username',$username)->first();
            return response()->json($index);

    }


    public function getManagerProject($username){
        $index = DB::table('manager_approves')->where('manager_name',$username)->get();
        return response()->json($index);
    }
    public function getManagerProjectClient($project){
        $index = DB::table('clients')->where('clientUnderProject',$project)->get();
        return response()->json($index);
    }

    public function getClientAllProject($client){
        $index = DB::table('clients')->where('name',$client)->get();
        return response()->json($index);
    }

    public function getManagerAll(){
        $index= Manager::all();
        return response()->json($index);
    }
    public function manager_delete($id){
        $index = DB::table('managers')->where('id',$id)->first();
        DB::table('manager_approves')->where('manager_name',$index->username)->delete();
        DB::table('managers')->where('id',$id)->delete();

    }



    public function update_admin_current_password(Request $request){
        $admin = DB::table("admins")->where('username',$request->username)->first();

        if($admin && Hash::check($request->old_password,$admin->password)){
           DB::table('admins')->where('username',$request->username)->update(['password'=>Hash::make($request->new_password)]);
           return response()->json(['success'=>'Password Changed Successfully']);

        }else{
            return response()->json(['error'=>'Old password is incorrect']);
        }
    }
    public function update_manager_current_password(Request $request){
        $admin = DB::table("managers")->where('username',$request->username)->first();

        if($admin && Hash::check($request->old_password,$admin->password)){
            DB::table('managers')->where('username',$request->username)->update(['password'=>Hash::make($request->new_password)]);
            return response()->json(['success'=>'Password Changed Successfully']);

        }else{
            return response()->json(['error'=>'Old password is incorrect']);
        }
    }
    public function reset_notification(){
        $index = DB::table('notifications')->latest('created_at')->update(['notification'=>0]);
    }

    public function fetch_access($manager){
        $index = DB::table('accounts_accesses')->where('manager_name',$manager)->first();
        return response()->json($index);
    }
    public function getReceiptvouchers($project){
        $index = DB::table('receipt_vouchers')->where('selectedProject',$project)->get();
        return response()->json($index);
    }
    public function getPaymentvouchers($project){
        $index = DB::table('payment_vouchers')->where('selectedProject',$project)->get();
        return response()->json($index);
    }
    public function getManagerPayable($project){
        $getPayable = DB::table('pay_payables')->pluck('payment_id');

        $index = payable_journal::whereNotIn('payment_id', $getPayable)->where('project',$project)->get();
        return response()->json($index);
    }

    public function getManagerPayableAll($project){
        $index = DB::table('pay_payables')->where('project',$project)->join('payable_journals', 'pay_payables.payment_id', '=', 'payable_journals.payment_id')->select('pay_payables.*')->get();
        return response()->json($index);
    }
    public function getManagerReceivableAll($project){

        $index = DB::table('pay_receivables')->where('project',$project)->join('receipt_payable_journals', 'pay_receivables.receipt_id', '=', 'receipt_payable_journals.receipt_id')->select('pay_receivables.*')->get();
        return response()->json($index);
    }
    public function getManagerReceiptPayable($project){
        $getPayable = DB::table('pay_receivables')->pluck('receipt_id');

        $index = ReceiptPayableJournal::whereNotIn('receipt_id', $getPayable)->where('project',$project)->get();
        return response()->json($index);
    }

    public function manager_fetch_employee($project){
        $index = DB::table('employees')->where('selectedProject',$project)->get();
        return response()->json($index);
    }
    public function manager_fetch_expense($project){
        $index = DB::table('expenses')->where('selectedProject',$project)->get();
        return response()->json($index);
    }

    public function fetch_client(){
        $index = DB::table('receipt_vouchers')->select('receipt_vouchers.selectedProject')->distinct()->get();
        return response()->json($index);
    }
    public function fetch_client_by_project($project){
        $index = DB::table('receipt_vouchers')->where('selectedProject',$project)->select('receipt_vouchers.client_id')->distinct()->get();
        return response()->json($index);
    }

    public function fetch_client_accounts($client_id){
        $indexarray=[];
        $totalPaid = 0;
        $totalDue = 0;
        $totalAmount = 0;
        $count = 0;
        $client_get = DB::table('receipt_vouchers')->where('client_id',$client_id)->get();
        if($client_get){
            foreach($client_get as $cg){
                $totalAmount+= intval($cg->product_amount);
                $totalDue += intval($cg->due);
                $totalPaid += intval($cg->total_amount);
                $count++;
            }
        }
        $client = DB::table('receipt_vouchers')->where('client_id',$client_id)->first();

        $indexarray [] = [
            'total_amount'=>$totalAmount,
            'total_due'=>$totalDue,
            'total_paid'=>$totalPaid,
            'client_name'=>$client->client_name,
            'phone'=>$client->client_phone,
             'share'=>$count,
        ];
        return response()->json($indexarray);
    }

    public function getManagerProjectClientList($project){
        $index = DB::table('receipt_vouchers')->where('receipt_vouchers.selectedProject',$project)->select('receipt_vouchers.selectedProject')->distinct()->get();
        return response()->json($index);
    }
    public function project($project){
        $index = DB::table('projects')->where('project_name',$project)->select('projects.project_address')->first();
        return response()->json($index);
    }
    public function fetch_access_manager(){
        $index= DB::table('accounts_accesses')->get();
        return response()->json($index);
    }
    public function delete_accounts_access($id){
        Db::table('accounts_accesses')->where('id',$id)->delete();
    }
}
