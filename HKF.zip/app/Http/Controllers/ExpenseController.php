<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use App\Models\Expense;
use Carbon\Carbon;
class ExpenseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $expense =  Expense::all();
        return response()->json($expense);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $expense = new Expense;
        $expense->financialYear = $request->financialYear;
        $expense->basic_date = $request->basic_date;
        $expense->selectedPaymentType = $request->selectedPaymentType;
        $expense->selectedProject = $request->selectedProject;
        $expense->product_name = $request->product_name;
        $expense->receive_amount = $request->receive_amount;
        $expense->payment_id = $request->payment_id;

        if ($request->selectedPaymentType == 'Cheque') {
            $expense->bank_cheque_no = $request->bank_cheque_no;
            $expense->bank_cheque_date = $request->bank_cheque_date;
            $expense->bank_name = $request->bank_name;
            $expense->bank_branch = $request->bank_branch;
            $expense->cash_bank_account  = $request->cash_bank_account;
        } else if ($request->selectedPaymentType == 'Cash') {
            $expense->bank_cheque_no = null;
            $expense->bank_cheque_date = null;
            $expense->bank_name = null;
            $expense->bank_branch = null;


        }
        $expense->save();
        //end expense


        //end
        return response()->json($expense);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $expense = Expense::find($id);
        return response()->json($expense);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $expense =  Expense::find($id);
        $expense->financialYear = $request->financialYear;
        $expense->basic_date = $request->basic_date;
        $expense->selectedPaymentType = $request->selectedPaymentType;
        $expense->selectedProject = $request->selectedProject;
        $expense->product_name = $request->product_name;
        $expense->receive_amount = $request->receive_amount;
        $expense->payment_id = $request->payment_id;
        if ($request->selectedPaymentType == 'Cheque') {
            $expense->bank_cheque_no = $request->bank_cheque_no;
            $expense->bank_cheque_date = $request->bank_cheque_date;
            $expense->bank_name = $request->bank_name;
            $expense->bank_branch = $request->bank_branch;
            $expense->cash_bank_account  = $request->cash_bank_account;

        } else if ($request->selectedPaymentType == 'Cash') {
            $expense->bank_cheque_no = null;
            $expense->bank_cheque_date = null;
            $expense->bank_name = null;
            $expense->bank_branch = null;
            $expense->cash_bank_account  = null;

        }
        $expense->save();
    }

    public function totalExpense(Request $request){
        $startdate = Carbon::createFromFormat('Y-m-d',$request->startDate);
        $enddate = Carbon::createFromFormat('Y-m-d',$request->endDate);
        $index = DB::table('expenses')->select('expenses.*')->whereBetween('basic_date',[$startdate,$enddate])->get();
        $totalBalance = 0;
       if($index){
        foreach($index as $ind){
            $totalBalance = $totalBalance+ intval($ind->receive_amount);
        }
       }
       $data =[ 'totalExpense'=>$totalBalance];
        return response()->json($data);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
