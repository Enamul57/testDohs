<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\Inventory;
use Illuminate\Support\Facades\DB;
class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $index = Inventory::all();
        return response()->json($index);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $inventory = new Inventory;
        $inventory->property_name = $request->property_name;
        $inventory->location = $request->location;
        if($request->property_project){
            $inventory->property_project = $request->property_project;
        }else{
            $inventory->property_project = "";
        }
        $inventory->property_amount = $request->property_amount;
        $inventory->property_type = $request->property_type;
        $inventory->sub_property_type = $request->sub_property_type;
        $inventory->property_id = $request->property_id;
        $inventory->squareft = $request->squareft;
        $inventory->property_status = $request->property_status;
        $inventory->property_details = $request->property_details;
        $inventory->building_name = $request->building_name;
        $inventory->size = $request->size;
        $inventory->daag_no = $request->daag_no;
        $inventory->sub_property_id = $request->sub_property_id;
        if($request->floor_level){
            $inventory->floor_level = $request->floor_level;
        }else{
            $inventory->floor_level = "";
        }
        $checkInventory = DB::table('inventories')->where('property_project',$request->property_project)->where('property_type',$request->property_type)->where('property_name',$request->property_name)->where('sub_property_type',$request->sub_property_type)->first();
        if($checkInventory){
            $exist = "This record has already exists!";
            return response()->json(['exist'=>$exist]);
        }
        else{
            $inventory->save();
        return response()->json($inventory);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $index = Inventory::find($id);
        return response()->json($index);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
        $inventory =  Inventory::find($id);
        $inventory->property_name = $request->property_name;
        $inventory->location = $request->location;
        if($request->property_project){
            $inventory->property_project = $request->property_project;
        }else{
            $inventory->property_project = "";
        }
        $inventory->property_amount = $request->property_amount;
        $inventory->property_type = $request->property_type;
        $inventory->sub_property_type = $request->sub_property_type;
        $inventory->property_id = $request->property_id;
        $inventory->squareft = $request->squareft;
        $inventory->property_status = $request->property_status;
        $inventory->property_details = $request->property_details;
        $inventory->building_name = $request->building_name;
        $inventory->size = $request->size;
        if($request->floor_level){
            $inventory->floor_level = $request->floor_level;
        }else{
            $inventory->floor_level = "";
        }
        $checkInventory = DB::table('inventories')->where('id',$id)->first();

            $inventory->save();

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
